import React from "react";
import { ShieldCheck, ToggleLeft, ToggleRight, Check, AlertTriangle, Users, Settings, Cpu, DollarSign } from "lucide-react";
import { FeatureFlags, Course, Transaction } from "../types";

interface AdminDashboardProps {
  featureFlags: FeatureFlags;
  courses: Course[];
  transactions: Transaction[];
  onToggleFlag: (flagName: keyof FeatureFlags) => void;
}

export default function AdminDashboard({
  featureFlags,
  courses,
  transactions,
  onToggleFlag
}: AdminDashboardProps) {
  
  const pendingApprovals = [
    { title: "HSC Organic Chemistry Reactions Guide", instructor: "Dr. Mashruf Ahmed", date: "Today" },
    { title: "Arabic for Beginners: Quranic Grammar", instructor: "Farhan Tanvir", date: "Yesterday" }
  ];

  const teacherVerifications = [
    { name: "Dr. Rakib Hasan", status: "Verified", certs: "Ph.D. BUET", active: true },
    { name: "Engr. Sajjad Hossain", status: "Verified", certs: "B.Sc. KUET", active: true },
    { name: "S.M. Rafiqul", status: "Pending", certs: "MA English DU", active: false }
  ];

  return (
    <div className="space-y-10 pb-20">
      
      {/* Platform security & diagnostic alerts */}
      <section className="p-4 rounded-xl bg-violet-950/20 border border-violet-800/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-6 w-6 text-violet-400" />
          <div className="text-xs">
            <span className="font-bold text-white">Security Guard System</span>
            <p className="text-slate-400 mt-0.5">JWT Auth is active, Two-Factor Authentication is simulated. Rate limits set to 100 req/min.</p>
          </div>
        </div>
        <div className="rounded-full bg-emerald-950 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-800/40 uppercase tracking-wide">
          Healthy State
        </div>
      </section>

      {/* Main Grid: CMS on Left, Payments & Flags on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Approvals and CMS */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Settings className="h-4 w-4 text-violet-400" />
              Content approvals and teacher verification CMS
            </h3>
            <p className="text-xs text-slate-400">Approve course syllabus layouts before they reach the main public catalog index.</p>

            <div className="space-y-3">
              {pendingApprovals.map((app, i) => (
                <div key={i} className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 flex items-center justify-between">
                  <div className="text-xs">
                    <span className="font-bold text-slate-200 block">{app.title}</span>
                    <span className="text-[10px] text-slate-500 font-mono">Submitted by: {app.instructor} • {app.date}</span>
                  </div>
                  <button className="rounded bg-violet-600 px-3 py-1.5 text-[10px] font-bold text-white hover:brightness-110 flex items-center gap-1">
                    <Check className="h-3.5 w-3.5" /> Approve
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="h-4 w-4 text-indigo-400" />
              Educator verification roster
            </h3>
            <p className="text-xs text-slate-400 font-medium">Verify credentials and identity certificates of instructor applicants.</p>

            <div className="divide-y divide-slate-800/60 text-xs">
              {teacherVerifications.map((teacher, i) => (
                <div key={i} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-200 block">{teacher.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{teacher.certs}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide ${
                    teacher.active ? "bg-emerald-950 text-emerald-400 border border-emerald-800/40" : "bg-amber-950 text-amber-400 border border-amber-800/40"
                  }`}>
                    {teacher.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Feature Flag & Modular Payments Panel */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="h-4 w-4 text-violet-400 animate-pulse" />
              Modular payment gateway / Feature flags
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enable or disable core system configurations. Activating "Course Purchase" turns on simulated SSLCommerz, bKash, and credit card gateways.
            </p>

            <div className="space-y-4">
              
              {/* Flag Row: Course Purchase */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-850">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-200 block">Course Purchase</span>
                  <p className="text-[9px] text-slate-500 font-medium leading-tight">Requires payment checkout when enrolling in premium courses.</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleFlag("coursePurchase")}
                  className="text-slate-400 hover:text-white transition-all shrink-0"
                >
                  {featureFlags.coursePurchase ? (
                    <ToggleRight className="h-8 w-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-slate-600" />
                  )}
                </button>
              </div>

              {/* Flag Row: Subscription Plans */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-850">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-200 block">Subscription Plans</span>
                  <p className="text-[9px] text-slate-500 font-medium leading-tight">Unlocks premium month-to-month and yearly subscription portals.</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleFlag("subscriptionPlans")}
                  className="text-slate-400 hover:text-white transition-all shrink-0"
                >
                  {featureFlags.subscriptionPlans ? (
                    <ToggleRight className="h-8 w-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-slate-600" />
                  )}
                </button>
              </div>

              {/* Flag Row: Premium Membership */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-850">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-200 block">Premium Membership</span>
                  <p className="text-[9px] text-slate-500 font-medium leading-tight">Enables VIP chat lounge, elite mock exams and study group modules.</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleFlag("premiumMembership")}
                  className="text-slate-400 hover:text-white transition-all shrink-0"
                >
                  {featureFlags.premiumMembership ? (
                    <ToggleRight className="h-8 w-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-slate-600" />
                  )}
                </button>
              </div>

              {/* Flag Row: Coupon System */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-850">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-200 block">Coupon Validation</span>
                  <p className="text-[9px] text-slate-500 font-medium leading-tight">Allows promo inputs (such as DISCOUNT50) at checkout.</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleFlag("couponSystem")}
                  className="text-slate-400 hover:text-white transition-all shrink-0"
                >
                  {featureFlags.couponSystem ? (
                    <ToggleRight className="h-8 w-8 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-slate-600" />
                  )}
                </button>
              </div>

            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
