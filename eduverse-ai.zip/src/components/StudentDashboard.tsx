import React, { useState } from "react";
import { BookOpen, GraduationCap, Award, Calendar, FolderOpen, Search, Star, MessageSquare, Plus, CheckCircle, Trash2, ArrowRight } from "lucide-react";
import { Course, Certificate, User } from "../types";

interface StudentDashboardProps {
  currentUser: User;
  courses: Course[];
  enrolledCourseIds: string[];
  completedLessons: string[];
  certificates: Certificate[];
  onSelectCourse: (course: Course) => void;
  onOpenAICopilot: () => void;
}

export default function StudentDashboard({
  currentUser,
  courses,
  enrolledCourseIds,
  completedLessons,
  certificates,
  onSelectCourse,
  onOpenAICopilot
}: StudentDashboardProps) {
  const [plannerGoalInput, setPlannerGoalInput] = useState("");
  const [goals, setGoals] = useState([
    { id: "g1", text: "Watch mechanics Lesson 2 & practice formulas", done: true },
    { id: "g2", text: "Complete React Foundations Quiz on Skill Masterclass", done: false },
    { id: "g3", text: "Solve 5 analytical vocabulary synonyms for BCS preps", done: false }
  ]);

  const enrolledCourses = courses.filter((c) => enrolledCourseIds.includes(c.id));

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!plannerGoalInput.trim()) return;
    setGoals([...goals, { id: `g_${Date.now()}`, text: plannerGoalInput, done: false }]);
    setPlannerGoalInput("");
  };

  const handleToggleGoal = (id: string) => {
    setGoals(goals.map((g) => (g.id === id ? { ...g, done: !g.done } : g)));
  };

  const handleDeleteGoal = (id: string) => {
    setGoals(goals.filter((g) => g.id !== id));
  };

  return (
    <div className="space-y-10 pb-20">
      
      {/* Analytics Overview Cards */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-6">
        
        {/* Enrolled Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-violet-950/50 text-violet-400 border border-violet-800/40">
            <BookOpen className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-white">{enrolledCourses.length}</div>
            <div className="text-xs text-slate-400 font-medium">Enrolled Courses</div>
          </div>
        </div>

        {/* Completion Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-950/50 text-emerald-400 border border-emerald-800/40">
            <CheckCircle className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-white">{completedLessons.length}</div>
            <div className="text-xs text-slate-400 font-medium">Completed Lessons</div>
          </div>
        </div>

        {/* Certified Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-950/50 text-amber-400 border border-amber-800/40">
            <Award className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-white">{certificates.length}</div>
            <div className="text-xs text-slate-400 font-medium">Certificates Earned</div>
          </div>
        </div>

        {/* Level XP Card */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-950/50 text-indigo-400 border border-indigo-800/40">
            <GraduationCap className="h-6 w-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-white">Lvl {currentUser.level}</div>
            <div className="text-xs text-slate-400 font-medium">{currentUser.xp} Total XP</div>
          </div>
        </div>

      </section>

      {/* Main Grid: Courses on Left, Planner & Certs on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Continue Learning */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">Continue Learning</h3>
            <span className="text-xs text-slate-500 font-mono">Current Student: {currentUser.name}</span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {enrolledCourses.map((course) => {
              // Calculate completion percentage
              const courseLessons = course.lessons || [];
              const courseLessonIds = courseLessons.map((l) => l.id);
              const completedCount = courseLessonIds.filter((id) => completedLessons.includes(id)).length;
              const percent = courseLessonIds.length > 0 ? Math.round((completedCount / courseLessonIds.length) * 100) : 0;

              return (
                <div
                  key={course.id}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
                >
                  <div className="space-y-2 flex-grow">
                    <span className="rounded bg-violet-950/80 px-2 py-0.5 text-[10px] font-bold text-violet-300 border border-violet-800/40 uppercase tracking-wider">
                      {course.subcategory}
                    </span>
                    <h4 className="text-base font-bold text-white">{course.title}</h4>
                    
                    {/* Completion bar */}
                    <div className="space-y-1 w-full max-w-sm">
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                        <span>Progress</span>
                        <span>{percent}%</span>
                      </div>
                      <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                        <div className="h-full bg-violet-500 rounded-full transition-all duration-300" style={{ width: `${percent}%` }}></div>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectCourse(course)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-violet-600 text-xs font-bold text-white shadow hover:brightness-110 transition-all flex items-center justify-center gap-1.5"
                  >
                    Resume Class
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}

            {enrolledCourses.length === 0 && (
              <div className="text-center py-12 rounded-2xl bg-slate-900 border border-slate-800">
                <span className="text-sm text-slate-400">You are not enrolled in any masterclasses yet. Enroll on the home screen!</span>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar: AI Study Planner */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-violet-400" />
                AI Study Planner
              </h3>
              <button
                onClick={onOpenAICopilot}
                className="text-[10px] font-bold text-violet-400 hover:underline"
              >
                Auto-Plan
              </button>
            </div>

            <form onSubmit={handleAddGoal} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter study goal..."
                value={plannerGoalInput}
                onChange={(e) => setPlannerGoalInput(e.target.value)}
                className="flex-grow rounded-lg bg-slate-950 px-3 py-1.5 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
              />
              <button className="rounded-lg bg-violet-600 px-3 text-xs font-bold text-white hover:brightness-110">
                <Plus className="h-4 w-4" />
              </button>
            </form>

            <div className="space-y-2 max-h-48 overflow-y-auto">
              {goals.map((goal) => (
                <div key={goal.id} className="flex items-center justify-between p-2 rounded bg-slate-950 text-xs border border-slate-850">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={goal.done}
                      onChange={() => handleToggleGoal(goal.id)}
                      className="rounded border-slate-800 bg-slate-900 text-violet-500 focus:ring-violet-500 cursor-pointer"
                    />
                    <span className={`text-slate-300 ${goal.done ? "line-through text-slate-500" : ""}`}>
                      {goal.text}
                    </span>
                  </div>
                  <button onClick={() => handleDeleteGoal(goal.id)} className="text-slate-600 hover:text-red-400">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Certificates & Download Center */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Certificates Viewer */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="h-5 w-5 text-amber-500" />
            Certifications List
          </h3>
          <p className="text-xs text-slate-400">Pass any final course quiz with 80%+ to generate verified credentials.</p>

          <div className="space-y-3">
            {certificates.map((cert) => (
              <div key={cert.id} className="p-4 rounded-xl bg-slate-950 border border-slate-850 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 font-mono">ID: {cert.id}</span>
                  <h4 className="text-xs font-bold text-slate-200 mt-1">{cert.courseTitle}</h4>
                  <p className="text-[10px] text-slate-400">Issued to: {cert.studentName}</p>
                </div>
                <div className="text-right">
                  <a
                    href={cert.qrCodeUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[10px] bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 hover:border-amber-500 text-amber-400 font-bold tracking-tight inline-block hover:bg-slate-850"
                  >
                    View QR Link
                  </a>
                </div>
              </div>
            ))}

            {certificates.length === 0 && (
              <div className="text-center py-6">
                <span className="text-xs text-slate-500">No certificates earned yet. Pass a masterclass quiz to generate your first certificate.</span>
              </div>
            )}
          </div>
        </div>

        {/* Resource Download Center */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-indigo-400" />
            Study Resource & Download Center
          </h3>
          <p className="text-xs text-slate-400">Quickly save course materials offline for study anywhere.</p>

          <div className="space-y-2.5 text-xs text-slate-300">
            <div className="p-3 rounded-lg bg-slate-950 border border-slate-850 flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200 block">Class 9 Physics Mechanics PDF</span>
                <span className="text-[10px] text-slate-500 font-mono">14.2 MB • NCTB Certified Syllabus</span>
              </div>
              <button className="px-2.5 py-1 text-[10px] bg-slate-900 border border-slate-800 rounded font-bold hover:text-white hover:border-slate-700">
                Download
              </button>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-850 flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200 block">Calculus Formulas Cheat-sheet</span>
                <span className="text-[10px] text-slate-500 font-mono">2.5 MB • Engineering Admissions Focused</span>
              </div>
              <button className="px-2.5 py-1 text-[10px] bg-slate-900 border border-slate-800 rounded font-bold hover:text-white hover:border-slate-700">
                Download
              </button>
            </div>
          </div>
        </div>

      </section>

      {/* Floating Smart AI Copilot CTA */}
      <section className="p-6 rounded-2xl bg-gradient-to-r from-violet-950/40 via-indigo-950/30 to-slate-950 border border-violet-800/40 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h4 className="text-sm font-extrabold text-violet-300 flex items-center gap-1">
            <MessageSquare className="h-4 w-4 animate-bounce text-violet-400" />
            Empower your studies with EduVerse AI Copilot
          </h4>
          <p className="text-xs text-slate-400">Summarize chapters, predict study gaps, get exam prep roadmaps instantly.</p>
        </div>
        <button
          onClick={onOpenAICopilot}
          className="rounded-xl bg-violet-600 px-5 py-2 text-xs font-bold text-white hover:brightness-110 shadow-lg"
        >
          Activate Tutor
        </button>
      </section>

    </div>
  );
}
