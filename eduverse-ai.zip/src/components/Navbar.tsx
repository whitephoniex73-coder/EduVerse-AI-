import React from "react";
import { BookOpen, User, ShieldAlert, Award, Star, Flame, Zap, RefreshCw, Rocket } from "lucide-react";
import { User as UserType, UserRole } from "../types";

interface NavbarProps {
  currentUser: UserType;
  allUsers: UserType[];
  onSwitchUser: (userId: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Navbar({
  currentUser,
  allUsers,
  onSwitchUser,
  activeTab,
  setActiveTab
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800 bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and Brand */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab("home")}>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-500 text-white shadow-lg shadow-indigo-500/20">
            <BookOpen className="h-5 w-5" />
          </div>
          <div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-violet-400 via-indigo-200 to-white bg-clip-text text-transparent">
              EduVerse <span className="text-violet-500">AI</span>
            </span>
            <div className="text-[9px] font-mono tracking-wider text-slate-500 uppercase">Bangladesh Ecosystem</div>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-300">
          <button
            onClick={() => setActiveTab("home")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "home" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            Home
          </button>
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "dashboard" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            My Dashboard
          </button>
          <button
            onClick={() => setActiveTab("live")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "live" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            Live Classes
          </button>
          <button
            onClick={() => setActiveTab("forum")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "forum" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            Community
          </button>
          <button
            onClick={() => setActiveTab("gamification")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "gamification" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            Rewards
          </button>
          <button
            onClick={() => setActiveTab("ai-copilot")}
            className={`px-3 py-2 rounded-lg transition-all flex items-center gap-1.5 font-semibold text-violet-300 ${
              activeTab === "ai-copilot" ? "bg-violet-950/40 text-violet-200 border border-violet-800/50" : "hover:text-violet-100"
            }`}
          >
            <Zap className="h-4 w-4 text-violet-400 animate-pulse" />
            AI Labs
          </button>
          <button
            onClick={() => setActiveTab("verification")}
            className={`px-3 py-2 rounded-lg transition-all ${
              activeTab === "verification" ? "bg-slate-900 text-white border border-slate-800" : "hover:text-white"
            }`}
          >
            Cert Verification
          </button>
          <button
            onClick={() => setActiveTab("pitch-deck")}
            className={`px-3 py-2 rounded-lg transition-all flex items-center gap-1.5 font-bold text-amber-300 ${
              activeTab === "pitch-deck" ? "bg-amber-950/40 text-amber-200 border border-amber-800/50" : "hover:text-amber-100"
            }`}
          >
            <Rocket className="h-4 w-4 text-amber-400" />
            Investor Pitch
          </button>
        </nav>

        {/* User Role Switcher & Profile Details */}
        <div className="flex items-center gap-4">
          
          {/* Quick Stats: XP & Streak */}
          <div className="hidden sm:flex items-center gap-3 rounded-full bg-slate-900 px-3 py-1.5 border border-slate-800 text-xs font-medium text-slate-300">
            <div className="flex items-center gap-1 text-amber-500" title="Daily Streak">
              <Flame className="h-4 w-4 fill-amber-500 animate-bounce" />
              <span>{currentUser.streak} Days</span>
            </div>
            <div className="h-3 w-px bg-slate-800"></div>
            <div className="flex items-center gap-1 text-violet-400" title="XP Points">
              <Zap className="h-3.5 w-3.5 fill-violet-400" />
              <span>Lvl {currentUser.level} ({currentUser.xp} XP)</span>
            </div>
          </div>

          {/* Quick Switch Dropdown */}
          <div className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-2 py-1 border border-slate-800">
            <RefreshCw className="h-3.5 w-3.5 text-slate-500" />
            <select
              value={currentUser.id}
              onChange={(e) => onSwitchUser(e.target.value)}
              className="bg-transparent text-xs font-semibold text-slate-300 focus:outline-none cursor-pointer pr-1"
              title="Switch role preview"
            >
              {allUsers.map((u) => (
                <option key={u.id} value={u.id} className="bg-slate-950 text-slate-300 text-xs">
                  {u.name} ({u.role})
                </option>
              ))}
            </select>
          </div>

          {/* User Profile Summary */}
          <div className="flex items-center gap-2 border-l border-slate-800 pl-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-800 text-white ring-2 ring-violet-500/30">
              <User className="h-4 w-4" />
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-xs font-bold text-white max-w-[120px] truncate">{currentUser.name}</div>
              <div className="text-[10px] text-slate-400 font-mono">{currentUser.role}</div>
            </div>
          </div>
        </div>

      </div>

      {/* Mobile navigation tab list */}
      <div className="flex md:hidden items-center justify-around border-t border-slate-900 bg-slate-950 py-2.5 text-xs">
        <button
          onClick={() => setActiveTab("home")}
          className={`flex flex-col items-center gap-1 ${activeTab === "home" ? "text-violet-400" : "text-slate-400"}`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Home</span>
        </button>
        <button
          onClick={() => setActiveTab("dashboard")}
          className={`flex flex-col items-center gap-1 ${activeTab === "dashboard" ? "text-violet-400" : "text-slate-400"}`}
        >
          <User className="h-4 w-4" />
          <span>My Portal</span>
        </button>
        <button
          onClick={() => setActiveTab("live")}
          className={`flex flex-col items-center gap-1 ${activeTab === "live" ? "text-violet-400" : "text-slate-400"}`}
        >
          <Zap className="h-4 w-4 animate-pulse" />
          <span>Live</span>
        </button>
        <button
          onClick={() => setActiveTab("forum")}
          className={`flex flex-col items-center gap-1 ${activeTab === "forum" ? "text-violet-400" : "text-slate-400"}`}
        >
          <Star className="h-4 w-4" />
          <span>Forum</span>
        </button>
        <button
          onClick={() => setActiveTab("ai-copilot")}
          className={`flex flex-col items-center gap-1 ${activeTab === "ai-copilot" ? "text-violet-400" : "text-slate-400"}`}
        >
          <ShieldAlert className="h-4 w-4 text-violet-500" />
          <span>AI Labs</span>
        </button>
        <button
          onClick={() => setActiveTab("pitch-deck")}
          className={`flex flex-col items-center gap-1 ${activeTab === "pitch-deck" ? "text-amber-400" : "text-slate-400"}`}
        >
          <Rocket className="h-4 w-4 text-amber-500" />
          <span>Pitch</span>
        </button>
      </div>
    </header>
  );
}
