import React, { useState } from "react";
import { Plus, Trash2, Layout, BookOpen, BarChart3, HelpCircle, AlertCircle, Percent, TrendingUp } from "lucide-react";
import { Course } from "../types";

interface InstructorDashboardProps {
  courses: Course[];
  onAddCourse: (newCourse: {
    title: string;
    description: string;
    category: string;
    subcategory: string;
    price: number;
    duration: string;
    lessons: { title: string; duration: string }[];
  }) => void;
}

export default function InstructorDashboard({ courses, onAddCourse }: InstructorDashboardProps) {
  // Course creation state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Skills");
  const [subcategory, setSubcategory] = useState("Web Development");
  const [price, setPrice] = useState(3000);
  const [duration, setDuration] = useState("15 hours");
  const [lessons, setLessons] = useState<{ title: string; duration: string }[]>([
    { title: "Lesson 1: Introduction", duration: "10:00" },
    { title: "Lesson 2: Core Concepts", duration: "25:00" }
  ]);
  const [newLessonTitle, setNewLessonTitle] = useState("");
  const [newLessonDuration, setNewLessonDuration] = useState("");

  const [notification, setNotification] = useState("");

  const handleAddLessonInput = () => {
    if (!newLessonTitle.trim()) return;
    setLessons([...lessons, { title: newLessonTitle, duration: newLessonDuration || "15:00" }]);
    setNewLessonTitle("");
    setNewLessonDuration("");
  };

  const handleRemoveLessonInput = (index: number) => {
    setLessons(lessons.filter((_, i) => i !== index));
  };

  const handleSubmitCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setNotification("Please fill in course title and description.");
      return;
    }
    
    onAddCourse({
      title,
      description,
      category,
      subcategory,
      price: Number(price),
      duration,
      lessons
    });

    setTitle("");
    setDescription("");
    setLessons([
      { title: "Lesson 1: Introduction", duration: "10:00" },
      { title: "Lesson 2: Core Concepts", duration: "25:00" }
    ]);
    setNotification("Course successfully added to EduVerse Ecosystem!");
    setTimeout(() => setNotification(""), 4000);
  };

  // Instructor-specific stats summary
  const totalStudents = courses.reduce((acc, c) => acc + c.studentsEnrolled, 0);
  const estimatedRevenue = courses.reduce((acc, c) => acc + (c.studentsEnrolled * c.price), 0);

  return (
    <div className="space-y-10 pb-20">
      
      {/* Revenue & Engagement Analytics */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium uppercase tracking-wider">
            <span>Total Student Enrollments</span>
            <BookOpen className="h-4 w-4 text-violet-400" />
          </div>
          <div className="text-3xl font-black text-white">{totalStudents.toLocaleString()}</div>
          <p className="text-[10px] text-emerald-400 font-medium">↑ +14.2% Growth this week</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium uppercase tracking-wider">
            <span>Estimated Gross Revenue</span>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-white">{estimatedRevenue.toLocaleString()} BDT</div>
          <p className="text-[10px] text-slate-400 font-mono">Platform fee: 10% standard</p>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium uppercase tracking-wider">
            <span>Average Course Rating</span>
            <BarChart3 className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-3xl font-black text-white">4.92 / 5.0</div>
          <p className="text-[10px] text-slate-400">Based on 4,890 verified student feedback ratings</p>
        </div>

      </section>

      {/* Main Grid: Course Builder vs Course Portfolio */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Course Builder Module */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-1.5">
              <Layout className="h-5 w-5 text-violet-400" />
              Dynamic Course Builder
            </h3>
            <p className="text-xs text-slate-400">Submit new modules directly to the system catalog in real-time.</p>
          </div>

          {notification && (
            <div className="p-3 rounded-lg bg-violet-950/40 border border-violet-800/40 text-xs text-violet-300">
              {notification}
            </div>
          )}

          <form onSubmit={handleSubmitCourse} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Course Title</label>
                <input
                  type="text"
                  placeholder="e.g. Mastering English Grammar for SSC"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Price (BDT)</label>
                <input
                  type="number"
                  placeholder="e.g. 2500"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
                >
                  <option value="Academic">Academic</option>
                  <option value="Admission">Admission</option>
                  <option value="Government">Government</option>
                  <option value="Skills">Skills</option>
                  <option value="Language">Language</option>
                  <option value="Professional">Professional</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Subcategory</label>
                <input
                  type="text"
                  placeholder="e.g. SSC, Class 8, Web Dev"
                  value={subcategory}
                  onChange={(e) => setSubcategory(e.target.value)}
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Total Duration</label>
                <input
                  type="text"
                  placeholder="e.g. 20 hours"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-bold">Course Description</label>
              <textarea
                placeholder="Describe the learning objectives, course targets, and materials..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none focus:border-violet-500"
              />
            </div>

            {/* Lesson upload builder */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-3">
              <div className="font-bold text-slate-200">Syllabus Lessons Configuration</div>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Lesson title (e.g. 1. Introduction to Variables)"
                  value={newLessonTitle}
                  onChange={(e) => setNewLessonTitle(e.target.value)}
                  className="flex-grow rounded bg-slate-900 px-3 py-1.5 text-white placeholder-slate-600 border border-slate-800 focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Duration (e.g. 15:00)"
                  value={newLessonDuration}
                  onChange={(e) => setNewLessonDuration(e.target.value)}
                  className="w-24 rounded bg-slate-900 px-3 py-1.5 text-white placeholder-slate-600 border border-slate-800 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddLessonInput}
                  className="rounded bg-violet-600 px-4 py-1.5 text-xs font-bold text-white hover:brightness-110"
                >
                  Add
                </button>
              </div>

              {/* Added lesson chips */}
              <div className="space-y-2">
                {lessons.map((lesson, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded bg-slate-900 text-xs border border-slate-850">
                    <span className="text-slate-300">{i + 1}. {lesson.title} ({lesson.duration})</span>
                    <button type="button" onClick={() => handleRemoveLessonInput(i)} className="text-slate-500 hover:text-red-400">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full rounded-xl bg-gradient-to-r from-violet-600 to-indigo-500 py-3 font-bold text-white shadow-lg hover:brightness-110 transition-all text-sm"
            >
              Publish Course to EduVerse Catalog
            </button>
          </form>
        </div>

        {/* Course Portfolio & Coupons */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white">Your Course Portfolio</h3>
            
            <div className="space-y-3">
              {courses.slice(0, 3).map((course) => (
                <div key={course.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 space-y-1">
                  <div className="font-bold text-slate-200 text-xs truncate">{course.title}</div>
                  <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                    <span>Enrolled: {course.studentsEnrolled}</span>
                    <span>Rating: {course.rating.toFixed(1)} ★</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Percent className="h-4 w-4 text-emerald-400" />
              Coupon & Engagement Settings
            </h3>
            
            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-850 space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-emerald-400">DISCOUNT50</span>
                  <span className="text-slate-500">Active</span>
                </div>
                <p className="text-[10px] text-slate-400">Applies 50% discount on any course checkout.</p>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-850 space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-violet-400">EDUAI99</span>
                  <span className="text-slate-500">Draft</span>
                </div>
                <p className="text-[10px] text-slate-400">Promotional BDT 1,000 flat discount.</p>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
