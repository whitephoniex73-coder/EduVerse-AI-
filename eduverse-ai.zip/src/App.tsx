import React, { useState, useEffect } from "react";
import { User, Course, LiveSession, ForumPost, Certificate, Transaction, FeatureFlags } from "./types";
import Navbar from "./components/Navbar";
import HomeView from "./components/HomeView";
import StudentDashboard from "./components/StudentDashboard";
import InstructorDashboard from "./components/InstructorDashboard";
import ParentDashboard from "./components/ParentDashboard";
import AdminDashboard from "./components/AdminDashboard";
import CourseViewer from "./components/CourseViewer";
import LiveClassSimulator from "./components/LiveClassSimulator";
import DiscussionForum from "./components/DiscussionForum";
import AICopilot from "./components/AICopilot";
import VerificationPortal from "./components/VerificationPortal";
import GamificationCorner from "./components/GamificationCorner";
import PaymentCheckout from "./components/PaymentCheckout";
import PitchDeck from "./components/PitchDeck";
import { Loader2, ArrowLeft } from "lucide-react";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [enrolledCourses, setEnrolledCourses] = useState<string[]>([]);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [liveSessions, setLiveSessions] = useState<LiveSession[]>([]);
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [featureFlags, setFeatureFlags] = useState<FeatureFlags>({
    coursePurchase: false,
    subscriptionPlans: false,
    premiumMembership: false,
    couponSystem: false,
    affiliateProgram: false
  });

  // Navigation states
  const [activeTab, setActiveTab] = useState<string>("home");
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [activeLive, setActiveLive] = useState<LiveSession | null>(null);
  const [checkoutCourse, setCheckoutCourse] = useState<Course | null>(null);

  // Fetch initial system state from Express server-side
  useEffect(() => {
    fetchState();
  }, []);

  const fetchState = async () => {
    try {
      const response = await fetch("/api/state");
      const data = await response.json();
      
      setCurrentUser(data.currentUser);
      setUsers(data.users);
      setCourses(data.courses);
      setEnrolledCourses(data.enrolledCourses);
      setCompletedLessons(data.completedLessons);
      setLiveSessions(data.liveSessions);
      setForumPosts(data.forumPosts);
      setCertificates(data.certificates);
      setTransactions(data.transactions);
      setFeatureFlags(data.featureFlags);
    } catch (err) {
      console.error("Failed to fetch initial state", err);
    } finally {
      setLoading(false);
    }
  };

  // Switch Active user/role (Student, Instructor, Admin, Parent)
  const handleSwitchUser = async (userId: string) => {
    try {
      const res = await fetch("/api/auth/switch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentUser(data.currentUser);
        // Clear active screen details to avoid mismatching view configurations
        setActiveCourse(null);
        setActiveLive(null);
        setActiveTab("dashboard");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Trigger Checkout / instant enrollment
  const handleEnrollInit = (courseId: string) => {
    const target = courses.find((c) => c.id === courseId);
    if (target) {
      setCheckoutCourse(target);
    }
  };

  // Confirm and save checkout transaction to server
  const handleConfirmEnrollment = async (paymentGateway?: string, couponCode?: string) => {
    if (!checkoutCourse) return;

    try {
      const res = await fetch("/api/courses/enroll", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          courseId: checkoutCourse.id,
          paymentGateway,
          couponCode
        })
      });
      const data = await res.json();
      if (data.success) {
        setEnrolledCourses(data.enrolledCourses);
        setTransactions(data.transactions);
        setCheckoutCourse(null);
        // Immediately view newly enrolled course details
        setActiveCourse(checkoutCourse);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Mark lesson complete
  const handleMarkLessonComplete = async (lessonId: string) => {
    try {
      const res = await fetch("/api/courses/lesson-complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lessonId })
      });
      const data = await res.json();
      if (data.success) {
        setCompletedLessons(data.completedLessons);
        if (currentUser) {
          setCurrentUser(data.currentUser);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Quiz submission & certificate generation
  const handleSubmitQuiz = async (courseId: string, score: number, totalQuestions: number) => {
    try {
      const res = await fetch("/api/courses/quiz-submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ courseId, score, totalQuestions })
      });
      const data = await res.json();
      if (data.success) {
        setCertificates(data.certificates);
        if (currentUser) {
          setCurrentUser(data.currentUser);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Add course (Instructor Dashboard)
  const handleAddCourse = async (newCourse: any) => {
    try {
      const res = await fetch("/api/courses/add-course", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCourse)
      });
      const data = await res.json();
      if (data.success) {
        setCourses(data.courses);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Vote on live class poll
  const handleVotePoll = async (sessionId: string, pollId: string, optionIndex: number) => {
    try {
      const res = await fetch("/api/live/poll-vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, pollId, optionIndex })
      });
      const data = await res.json();
      if (data.success) {
        setLiveSessions(data.liveSessions);
        // Refresh active reference
        const updatedLive = data.liveSessions.find((s: any) => s.id === sessionId);
        if (updatedLive) setActiveLive(updatedLive);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Send message in live chat
  const handleSendLiveMessage = async (sessionId: string, message: string) => {
    try {
      const res = await fetch("/api/live/chat-send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, message })
      });
      const data = await res.json();
      if (data.success) {
        setLiveSessions(data.liveSessions);
        // Refresh active reference
        const updatedLive = data.liveSessions.find((s: any) => s.id === sessionId);
        if (updatedLive) setActiveLive(updatedLive);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Create discussion thread
  const handleCreatePost = async (title: string, content: string, category: string) => {
    try {
      const res = await fetch("/api/forum/create-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, category })
      });
      const data = await res.json();
      if (data.success) {
        setForumPosts(data.forumPosts);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Reply to discussion thread
  const handleAddReply = async (postId: string, content: string) => {
    try {
      const res = await fetch("/api/forum/reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId, content })
      });
      const data = await res.json();
      if (data.success) {
        setForumPosts(data.forumPosts);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Toggle admin feature flag
  const handleToggleFlag = async (flagName: keyof FeatureFlags) => {
    try {
      const res = await fetch("/api/admin/toggle-flag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ flagName })
      });
      const data = await res.json();
      if (data.success) {
        setFeatureFlags(data.featureFlags);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // AI API connectors (to server-side proxy routes)
  const onSendMessage = async (message: string) => {
    const res = await fetch("/api/ai/tutor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    return res.json();
  };

  const onGenerateQuiz = async (topic: string, difficulty: string) => {
    const res = await fetch("/api/ai/exam-gen", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ topic, difficulty })
    });
    return res.json();
  };

  const onGetCareerAdvice = async (targetRole: string, currentSkills: string) => {
    const res = await fetch("/api/ai/career", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetRole, currentSkills })
    });
    return res.json();
  };

  const onTranslateText = async (text: string, targetLanguage: string) => {
    const res = await fetch("/api/ai/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, targetLanguage })
    });
    return res.json();
  };

  // Show generic loading spinner during initial payload fetching
  if (loading || !currentUser) {
    return (
      <div className="flex h-screen w-screen flex-col items-center justify-center bg-slate-950 text-slate-200">
        <Loader2 className="h-8 w-8 animate-spin text-violet-500 mb-2" />
        <span className="text-xs font-mono uppercase tracking-widest text-slate-400">Loading EduVerse AI Ecosystem...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Platform Navigation bar */}
      <Navbar
        currentUser={currentUser}
        allUsers={users}
        onSwitchUser={handleSwitchUser}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          // Clear active detail pages when hitting root tabs
          setActiveCourse(null);
          setActiveLive(null);
          setActiveTab(tab);
        }}
      />

      {/* Main viewport Container */}
      <main className="flex-grow mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Back button wrapper for internal detailed pages */}
        {(activeCourse || activeLive) && (
          <button
            onClick={() => {
              setActiveCourse(null);
              setActiveLive(null);
            }}
            className="mb-6 flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Catalog
          </button>
        )}

        {/* Dynamic Route Renderers */}
        {activeCourse ? (
          <CourseViewer
            course={activeCourse}
            completedLessonIds={completedLessons}
            onMarkLessonComplete={handleMarkLessonComplete}
            onSubmitQuiz={handleSubmitQuiz}
          />
        ) : activeLive ? (
          <LiveClassSimulator
            session={activeLive}
            currentUser={currentUser}
            onVotePoll={handleVotePoll}
            onSendChatMessage={handleSendLiveMessage}
          />
        ) : (
          <>
            {activeTab === "home" && (
              <HomeView
                courses={courses}
                liveSessions={liveSessions}
                enrolledCourseIds={enrolledCourses}
                onEnroll={handleEnrollInit}
                onViewCourse={(course) => setActiveCourse(course)}
                onViewLive={(session) => setActiveLive(session)}
              />
            )}

            {activeTab === "dashboard" && (
              <>
                {currentUser.role === "Student" && (
                  <StudentDashboard
                    currentUser={currentUser}
                    courses={courses}
                    enrolledCourseIds={enrolledCourses}
                    completedLessons={completedLessons}
                    certificates={certificates}
                    onSelectCourse={(course) => setActiveCourse(course)}
                    onOpenAICopilot={() => setActiveTab("ai-copilot")}
                  />
                )}

                {currentUser.role === "Parent" && (
                  <ParentDashboard
                    currentUser={currentUser}
                    certificates={certificates}
                    transactions={transactions}
                  />
                )}

                {currentUser.role === "Instructor" && (
                  <InstructorDashboard
                    courses={courses}
                    onAddCourse={handleAddCourse}
                  />
                )}

                {currentUser.role === "Admin" && (
                  <AdminDashboard
                    featureFlags={featureFlags}
                    courses={courses}
                    transactions={transactions}
                    onToggleFlag={handleToggleFlag}
                  />
                )}
              </>
            )}

            {activeTab === "live" && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-black text-white">Live Learning Studios</h2>
                  <p className="text-xs text-slate-400">Join real-time classrooms with digital whiteboards, screen sharing, and instant polling.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {liveSessions.map((session) => (
                    <div key={session.id} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
                      <div className="flex justify-between items-start">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                          session.status === "live" ? "bg-red-950 text-red-400 border border-red-800/50" : "bg-blue-950 text-blue-400 border border-blue-800/50"
                        }`}>
                          {session.status}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Students: {session.enrolledCount}</span>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-white line-clamp-1">{session.title}</h4>
                        <p className="text-xs text-slate-400 mt-1">Instructor: {session.instructorName}</p>
                      </div>

                      <button
                        onClick={() => setActiveLive(session)}
                        className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-850 text-xs font-bold text-slate-300 border border-slate-850 hover:border-slate-800 transition-all"
                      >
                        Join Interactive Classroom
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "forum" && (
              <DiscussionForum
                forumPosts={forumPosts}
                onCreatePost={handleCreatePost}
                onAddReply={handleAddReply}
              />
            )}

            {activeTab === "gamification" && (
              <GamificationCorner currentUser={currentUser} />
            )}

            {activeTab === "ai-copilot" && (
              <AICopilot
                onSendMessage={onSendMessage}
                onGenerateQuiz={onGenerateQuiz}
                onGetCareerAdvice={onGetCareerAdvice}
                onTranslateText={onTranslateText}
              />
            )}

            {activeTab === "verification" && (
              <VerificationPortal certificates={certificates} />
            )}

            {activeTab === "pitch-deck" && (
              <PitchDeck onBackToHome={() => setActiveTab("home")} />
            )}
          </>
        )}

      </main>

      {/* Modular Plug-and-Play checkout panel (modal overlay) */}
      {checkoutCourse && (
        <PaymentCheckout
          course={checkoutCourse}
          featureFlags={featureFlags}
          onCancel={() => setCheckoutCourse(null)}
          onConfirmEnrollment={handleConfirmEnrollment}
        />
      )}

    </div>
  );
}
