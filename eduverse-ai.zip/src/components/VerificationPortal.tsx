import React, { useState } from "react";
import { Award, CheckCircle, Search, Calendar, ShieldCheck, XCircle } from "lucide-react";
import { Certificate } from "../types";

interface VerificationPortalProps {
  certificates: Certificate[];
}

export default function VerificationPortal({ certificates }: VerificationPortalProps) {
  const [searchId, setSearchId] = useState("EV-CERT-740219");
  const [searched, setSearched] = useState(false);
  const [foundCert, setFoundCert] = useState<Certificate | null>(null);
  const [loading, setLoading] = useState(false);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    setSearched(true);
    setLoading(true);
    
    try {
      const res = await fetch(`/api/certificates/verify/${encodeURIComponent(searchId.trim())}`);
      if (res.ok) {
        const data = await res.json();
        setFoundCert(data.certificate || null);
      } else {
        setFoundCert(null);
      }
    } catch (err) {
      console.error("Verification error:", err);
      setFoundCert(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 pb-20">
      
      {/* Search Header card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 text-center">
        <Award className="h-10 w-10 text-violet-400 mx-auto animate-bounce" />
        <div className="space-y-1">
          <h2 className="text-xl font-black text-white">Public Certificate Verification Portal</h2>
          <p className="text-xs text-slate-400">Enter a unique EduVerse verification ID to audit student credentials and badges.</p>
        </div>

        <form onSubmit={handleVerify} className="flex gap-2 max-w-md mx-auto pt-2">
          <input
            type="text"
            placeholder="e.g. EV-CERT-740219"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="flex-grow rounded-lg bg-slate-950 px-3.5 py-2 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
          />
          <button type="submit" disabled={loading} className="rounded-lg bg-violet-600 px-5 text-xs font-bold text-white hover:brightness-110 flex items-center gap-1 disabled:opacity-50">
            <Search className="h-4 w-4" /> {loading ? "Verifying..." : "Verify"}
          </button>
        </form>
      </div>

      {/* Verification Result Card */}
      {searched && (
        <div className="animate-fade-in">
          {foundCert ? (
            <div className="p-6 rounded-2xl bg-slate-900 border border-emerald-800/40 relative overflow-hidden space-y-6">
              
              {/* Decorative green badge */}
              <div className="absolute top-0 right-0 p-3 bg-emerald-950/40 border-l border-b border-emerald-800/40 rounded-bl-xl text-emerald-400 font-mono text-[9px] font-bold tracking-wider flex items-center gap-1 uppercase">
                <CheckCircle className="h-3.5 w-3.5 fill-emerald-950" />
                Verified Credential
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 font-mono">Unique Verification Hash ID</span>
                <div className="text-sm font-bold font-mono text-white tracking-wide">{foundCert.id}</div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-4 border-t border-slate-800/60">
                <div className="space-y-1">
                  <span className="text-slate-500 font-bold uppercase tracking-wider block text-[9px]">Student Name</span>
                  <span className="text-slate-200 font-extrabold text-sm">{foundCert.studentName}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-500 font-bold uppercase tracking-wider block text-[9px]">Course Masterclass</span>
                  <span className="text-slate-200 font-extrabold text-sm">{foundCert.courseTitle}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-500 font-bold uppercase tracking-wider block text-[9px]">Issuer</span>
                  <span className="text-slate-200 font-extrabold">EduVerse Global Learning Ecosystem</span>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-500 font-bold uppercase tracking-wider block text-[9px]">Issue Date</span>
                  <span className="text-slate-200 font-extrabold">{new Date(foundCert.issuedAt).toLocaleDateString()}</span>
                </div>
              </div>

              {/* QR confirmation */}
              <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-950 p-4 rounded-xl border border-slate-850">
                <img
                  src={foundCert.qrCodeUrl}
                  alt="QR validation"
                  className="h-20 w-20 rounded bg-white p-1 border border-slate-800"
                  referrerPolicy="no-referrer"
                />
                <div className="text-xs space-y-1 text-center sm:text-left">
                  <span className="font-bold text-white flex items-center justify-center sm:justify-start gap-1">
                    <ShieldCheck className="h-4 w-4 text-emerald-400" /> Secure QR confirmation
                  </span>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    This QR links directly to our tamper-proof server registry. Scanning confirms the valid issuance of this certificate and its active accreditation.
                  </p>
                </div>
              </div>

            </div>
          ) : (
            <div className="p-6 rounded-2xl bg-slate-900 border border-red-800/40 text-center space-y-4">
              <XCircle className="h-10 w-10 text-red-500 mx-auto" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Accreditation ID Not Found</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  The registry was unable to locate certificate ID: "{searchId}". Please check for typos or retry with a valid student hash.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
