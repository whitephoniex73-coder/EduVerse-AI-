import React from "react";
import { Flame, Star, Trophy, Award, Target, Zap, ShieldCheck } from "lucide-react";
import { User } from "../types";

interface GamificationCornerProps {
  currentUser: User;
}

export default function GamificationCorner({ currentUser }: GamificationCornerProps) {
  const leaderboards = [
    { rank: 1, name: "Tahmid Hasan", institution: "BUET '26 Candidate", xp: 12400 },
    { rank: 2, name: "Farhana Chowdhury", institution: "HSC Science, DMC Focus", xp: 9800 },
    { rank: 3, name: "Rafid Rahman", institution: "Class 9 Student", xp: currentUser.xp, isUser: true },
    { rank: 4, name: "Zarin Tasnim", institution: "Class 10 SSC Prep", xp: 2100 },
    { rank: 5, name: "Ahsan Habib", institution: "BCS Aspirant", xp: 1850 }
  ].sort((a, b) => b.xp - a.xp);

  const activeBadges = [
    { title: "First Steps", desc: "Successfully enrolled in your very first EduVerse course module.", icon: Award, color: "text-blue-400 bg-blue-950/40 border-blue-800" },
    { title: "Streak Master", desc: "Attained a study streak of over 5 consecutive days of learning.", icon: Flame, color: "text-amber-500 bg-amber-950/40 border-amber-800" },
    { title: "Quiz Whiz", desc: "Passed a chapter quiz with an excellent score of 80% or above.", icon: Trophy, color: "text-violet-400 bg-violet-950/40 border-violet-800" },
    { title: "Course Master", desc: "Awarded after passing all core requirements of a course.", icon: Target, color: "text-emerald-400 bg-emerald-950/40 border-emerald-800" }
  ];

  const weeklyChallenges = [
    { text: "Solve 2 dynamic MCQ questions in AI Labs", xp: "+150 XP", done: false },
    { text: "Attend Newtonian Physics Live Classroom Stream", xp: "+200 XP", done: true },
    { text: "Submit 1 constructive reply in the discussion forum", xp: "+100 XP", done: true }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20">
      
      {/* Badges & Challenges Column */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Streak and XP status banner */}
        <div className="p-6 rounded-2xl bg-gradient-to-r from-violet-950/40 to-indigo-950/30 border border-violet-800/40 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-amber-500 font-bold">
              <Flame className="h-5 w-5 animate-bounce fill-amber-500" />
              <span>{currentUser.streak} Days Streak Active!</span>
            </div>
            <h3 className="text-base font-black text-white">Daily study streaks award double bonus XP!</h3>
            <p className="text-xs text-slate-400">Log in tomorrow to keep your daily study loop going strong.</p>
          </div>

          <div className="rounded-xl bg-slate-950 px-4 py-2 text-center border border-slate-800 min-w-[120px]">
            <span className="text-[10px] text-slate-500 font-mono block uppercase">Level Progress</span>
            <span className="text-lg font-extrabold text-violet-400">Level {currentUser.level}</span>
            <span className="text-[10px] text-slate-400 block font-mono">{currentUser.xp} XP</span>
          </div>
        </div>

        {/* Achievement Badges List */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Award className="h-4.5 w-4.5 text-violet-400" />
            Accreditation & Achievement Badges
          </h3>
          <p className="text-xs text-slate-400">Earn micro-badges for logging lessons, scoring high, and contributing questions.</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {activeBadges.map((badge, i) => {
              const UserHasBadge = currentUser.badges.includes(badge.title);
              const Icon = badge.icon;
              return (
                <div
                  key={i}
                  className={`p-4 rounded-xl border flex gap-3 items-start transition-all ${
                    UserHasBadge 
                      ? `${badge.color} shadow shadow-indigo-500/5` 
                      : "bg-slate-950/40 border-slate-900 text-slate-500 opacity-60"
                  }`}
                >
                  <div className="h-9 w-9 rounded-lg border border-current/20 flex items-center justify-center shrink-0">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="space-y-1">
                    <div className="font-extrabold flex items-center gap-1.5">
                      {badge.title}
                      {UserHasBadge && <span className="text-[8px] bg-slate-950 px-1 py-0.2 rounded font-mono text-current font-bold uppercase border border-current/20">Unlocked</span>}
                    </div>
                    <p className="text-[10px] leading-relaxed text-slate-400">{badge.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weekly Challenges */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Target className="h-4.5 w-4.5 text-indigo-400" />
            Weekly Learning Challenges
          </h3>
          
          <div className="space-y-2.5 text-xs">
            {weeklyChallenges.map((challenge, i) => (
              <div key={i} className="p-3 rounded-lg bg-slate-950 border border-slate-850 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={challenge.done}
                    readOnly
                    className="rounded border-slate-800 bg-slate-900 text-violet-500 cursor-not-allowed"
                  />
                  <span className={`text-slate-300 ${challenge.done ? "line-through text-slate-500" : ""}`}>{challenge.text}</span>
                </div>
                <span className="font-mono text-[10px] font-bold text-violet-400 shrink-0">{challenge.xp}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Global leaderboards column */}
      <div className="space-y-6">
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Trophy className="h-4.5 w-4.5 text-amber-500 animate-pulse" />
            National Student Leaderboard
          </h3>
          <p className="text-xs text-slate-400">Compete with student minds across Dhaka, Chittagong, Sylhet, and Rajshahi.</p>

          <div className="space-y-3.5 text-xs">
            {leaderboards.map((user, i) => (
              <div
                key={i}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  user.isUser 
                    ? "bg-violet-950/20 border-violet-800/60" 
                    : "bg-slate-950 border-slate-850"
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`font-mono text-xs font-black ${
                    i === 0 ? "text-amber-400" : i === 1 ? "text-slate-300" : "text-slate-500"
                  }`}>
                    #{i + 1}
                  </span>
                  <div>
                    <span className="font-bold text-slate-200 block">{user.name}</span>
                    <span className="text-[9px] text-slate-500 font-mono block">{user.institution}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono text-xs font-black text-violet-400">{user.xp} XP</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
}
