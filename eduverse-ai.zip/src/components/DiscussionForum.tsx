import React, { useState } from "react";
import { MessageSquare, ArrowUp, Plus, Send, Check } from "lucide-react";
import { ForumPost } from "../types";

interface DiscussionForumProps {
  forumPosts: ForumPost[];
  onCreatePost: (title: string, content: string, category: string) => void;
  onAddReply: (postId: string, content: string) => void;
}

export default function DiscussionForum({
  forumPosts,
  onCreatePost,
  onAddReply
}: DiscussionForumProps) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [activePostId, setActivePostId] = useState<string | null>(forumPosts[0]?.id || null);

  // Form states
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newCategory, setNewCategory] = useState("Academic");
  const [replyInput, setReplyInput] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);

  const categories = ["All", "Academic", "Government Job Prep", "Skills", "University & Admissions", "Careers"];

  const filteredPosts = forumPosts.filter((post) => {
    return selectedCategory === "All" || post.category === selectedCategory;
  });

  const activePost = forumPosts.find((p) => p.id === activePostId);

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    onCreatePost(newTitle, newContent, newCategory);
    setNewTitle("");
    setNewContent("");
    setShowCreateForm(false);
  };

  const handleReplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyInput.trim() || !activePostId) return;
    onAddReply(activePostId, replyInput);
    setReplyInput("");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20">
      
      {/* Thread list column */}
      <div className="space-y-6">
        
        {/* Actions header */}
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Community Threads</h3>
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="rounded-lg bg-violet-600 px-3 py-1.5 text-xs font-bold text-white hover:brightness-110 flex items-center gap-1 shadow"
          >
            <Plus className="h-4 w-4" /> New Post
          </button>
        </div>

        {/* Category pills list */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg border transition-all shrink-0 ${
                selectedCategory === cat
                  ? "bg-violet-950/40 text-violet-300 border-violet-800"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Create Thread Form */}
        {showCreateForm && (
          <form onSubmit={handlePostSubmit} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3.5 text-xs">
            <div className="font-bold text-slate-200">Start a new thread</div>

            <div className="space-y-1">
              <label className="text-slate-400 font-semibold">Title</label>
              <input
                type="text"
                placeholder="e.g. Need recommendation for Class 9 Biology book"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full rounded bg-slate-950 px-3 py-2 text-white border border-slate-800 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full rounded bg-slate-950 px-3 py-2 text-white border border-slate-800 focus:outline-none"
                >
                  <option value="Academic">Academic</option>
                  <option value="Government Job Prep">Government Job Prep</option>
                  <option value="Skills">Skills</option>
                  <option value="Careers">Careers</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 font-semibold">Content</label>
              <textarea
                placeholder="Describe your query, study problem, or resources query..."
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                rows={3}
                className="w-full rounded bg-slate-950 px-3 py-2 text-white border border-slate-800 focus:outline-none"
              />
            </div>

            <button type="submit" className="w-full rounded-lg bg-violet-600 py-2 font-bold text-white hover:brightness-110">
              Publish Thread
            </button>
          </form>
        )}

        {/* Threads list */}
        <div className="space-y-3">
          {filteredPosts.map((post) => {
            const active = post.id === activePostId;
            return (
              <div
                key={post.id}
                onClick={() => setActivePostId(post.id)}
                className={`p-4 rounded-xl border text-xs space-y-2 cursor-pointer transition-all ${
                  active 
                    ? "bg-slate-900 border-violet-500/50 shadow shadow-violet-500/5" 
                    : "bg-slate-900 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="rounded bg-violet-950/80 px-2 py-0.5 text-[8px] font-mono font-bold text-violet-300 border border-violet-800/40 uppercase tracking-wider">
                    {post.category}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">By {post.authorName}</span>
                </div>

                <h4 className="font-bold text-slate-200 line-clamp-1 leading-snug">
                  {post.title}
                </h4>

                <p className="text-slate-400 line-clamp-2 leading-relaxed">
                  {post.content}
                </p>

                <div className="flex items-center gap-4 text-[10px] text-slate-500 font-mono">
                  <div className="flex items-center gap-1">
                    <ArrowUp className="h-3.5 w-3.5" />
                    <span>{post.upvotes} Upvotes</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="h-3.5 w-3.5" />
                    <span>{post.replies.length} Replies</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Thread details replies viewport */}
      <div className="lg:col-span-2 space-y-6">
        {activePost ? (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6 flex flex-col justify-between min-h-[420px]">
            
            {/* Header Content block */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-500 font-mono">Category: {activePost.category}</span>
                <span className="text-[10px] text-slate-500 font-mono">Published: {new Date(activePost.createdAt).toLocaleDateString()}</span>
              </div>

              <h2 className="text-lg font-extrabold text-white leading-snug">
                {activePost.title}
              </h2>

              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-xs font-bold text-slate-300">
                  {activePost.authorName[0]}
                </div>
                <div>
                  <div className="text-xs font-bold text-white">{activePost.authorName}</div>
                  <div className="text-[9px] text-slate-400 uppercase tracking-wide font-mono">{activePost.authorRole}</div>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-850">
                {activePost.content}
              </p>
            </div>

            {/* Replies section */}
            <div className="space-y-4 pt-4 border-t border-slate-800/60 flex-grow">
              <div className="text-xs font-bold text-slate-200">Discussion replies ({activePost.replies.length})</div>

              <div className="space-y-3 max-h-48 overflow-y-auto">
                {activePost.replies.map((reply) => (
                  <div key={reply.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 space-y-1.5 text-xs">
                    <div className="flex items-center gap-2 justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-200">{reply.authorName}</span>
                        <span className="text-[8px] rounded bg-slate-900 px-1 py-0.2 border border-slate-800 text-slate-500 uppercase tracking-wide font-mono">{reply.authorRole}</span>
                      </div>
                      <span className="text-[9px] text-slate-500 font-mono">{new Date(reply.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">{reply.content}</p>
                  </div>
                ))}

                {activePost.replies.length === 0 && (
                  <div className="text-center py-6">
                    <span className="text-xs text-slate-500">No replies in this thread yet. Be the first to answer!</span>
                  </div>
                )}
              </div>
            </div>

            {/* Reply Input Form */}
            <form onSubmit={handleReplySubmit} className="flex gap-2 border-t border-slate-800/60 pt-4">
              <input
                type="text"
                placeholder="Write a constructive answer..."
                value={replyInput}
                onChange={(e) => setReplyInput(e.target.value)}
                className="flex-grow rounded-lg bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
              />
              <button className="rounded-lg bg-violet-600 px-4 text-xs font-bold text-white hover:brightness-110 flex items-center gap-1.5">
                <Send className="h-4 w-4" /> Reply
              </button>
            </form>

          </div>
        ) : (
          <div className="text-center py-20 rounded-2xl bg-slate-900 border border-slate-800">
            <span className="text-sm text-slate-400">Select a thread to view discussion replies.</span>
          </div>
        )}
      </div>

    </div>
  );
}
