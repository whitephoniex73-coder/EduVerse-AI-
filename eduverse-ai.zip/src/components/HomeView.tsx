import React, { useState, useEffect } from "react";
import { 
  Search, Sparkles, Star, Play, Clock, BookOpen, GraduationCap, Award, 
  Newspaper, ArrowRight, CheckCircle2, TrendingUp, Tv, Users, ShieldCheck, 
  Check, Plus, Send, Calendar, ChevronRight, Info, Lock, Mail, Phone, 
  MapPin, Github, Laptop, Brain, Compass, FileText, HelpCircle, 
  SendHorizontal, Code, UserCheck, ChevronDown, Smartphone, Flame, Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Course, LiveSession } from "../types";

interface HomeViewProps {
  courses: Course[];
  liveSessions: LiveSession[];
  enrolledCourseIds: string[];
  onEnroll: (courseId: string) => void;
  onViewCourse: (course: Course) => void;
  onViewLive: (session: LiveSession) => void;
}

export default function HomeView({
  courses,
  liveSessions,
  enrolledCourseIds,
  onEnroll,
  onViewCourse,
  onViewLive
}: HomeViewProps) {
  // General states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  
  // Navigation active tab anchors
  const categories = ["All", "Academic", "Admission", "Government", "Skills", "Language", "Professional"];

  // Filtered courses from state
  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.subcategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructorName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === "All" || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // --- INTERACTIVE SIMULATION STATES ---

  // 1. Authentication Simulator Modal
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authSuccessMsg, setAuthSuccessMsg] = useState("");
  const [twoFactorRequired, setTwoFactorRequired] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [mfaSuccess, setMfaSuccess] = useState(false);

  // 2. AI Tutor Section State
  const [aiTutorQuery, setAiTutorQuery] = useState("");
  const [aiTutorResponse, setAiTutorResponse] = useState("");
  const [aiTutorLoading, setAiTutorLoading] = useState(false);

  // 3. AI Study Planner State
  const [plannerGoal, setPlannerGoal] = useState("HSC Board Exam");
  const [plannerWeeks, setPlannerWeeks] = useState("12 Weeks");
  const [plannerSchedule, setPlannerSchedule] = useState<string[]>([]);
  const [plannerLoading, setPlannerLoading] = useState(false);

  // 4. AI Career Advisor State
  const [careerRole, setCareerRole] = useState("Software Engineer");
  const [careerSkills, setCareerSkills] = useState("HTML, CSS, JavaScript");
  const [careerAdvice, setCareerAdvice] = useState("");
  const [careerLoading, setCareerLoading] = useState(false);

  // 5. AI Exam Generator State
  const [examTopic, setExamTopic] = useState("English Grammar");
  const [examDifficulty, setExamDifficulty] = useState("Medium");
  const [examQuestions, setExamQuestions] = useState<any[]>([]);
  const [examAnswers, setExamAnswers] = useState<Record<number, number>>({});
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [examScore, setExamScore] = useState(0);
  const [examLoading, setExamLoading] = useState(false);

  // 6. Active AI Feature Showcase Tab
  const [activeAITab, setActiveAITab] = useState<"tutor" | "planner" | "career" | "exam">("tutor");

  // 7. Certificate Search State (optimized query target <100ms)
  const [searchCertId, setSearchCertId] = useState("EV-CERT-740219");
  const [certResult, setCertResult] = useState<any>(null);
  const [certSearched, setCertSearched] = useState(false);
  const [certLoading, setCertLoading] = useState(false);

  // 8. Newsletter State
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // 9. FAQ Accordion States
  const [openFAQIndex, setOpenFAQIndex] = useState<number | null>(0);

  // --- SIMULATION HANDLERS ---

  // Handle Login / Register Simulation
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authEmail || !authPassword) return;
    
    setAuthSuccessMsg("");
    setTwoFactorRequired(false);

    if (authMode === "login") {
      // Simulate enterprise 2FA requirement
      setTwoFactorRequired(true);
    } else {
      setAuthSuccessMsg("Account pre-registered! Standard dynamic verification link dispatched to " + authEmail);
    }
  };

  const handleMfaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (twoFactorCode === "123456" || twoFactorCode.length === 6) {
      setMfaSuccess(true);
      setAuthSuccessMsg("Two-Factor Authentication Succeeded. Enterprise Role Secured!");
      setTimeout(() => {
        setAuthModalOpen(false);
        setTwoFactorRequired(false);
        setMfaSuccess(false);
        setAuthEmail("");
        setAuthPassword("");
        setTwoFactorCode("");
      }, 2000);
    } else {
      alert("Invalid 2FA code. Please input any 6 digit code (e.g. 123456)");
    }
  };

  // Run AI Tutor Query Simulation (communicates with backend proxy API)
  const handleAiTutorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiTutorQuery.trim()) return;
    setAiTutorLoading(true);
    setAiTutorResponse("");
    try {
      const response = await fetch("/api/ai/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: aiTutorQuery })
      });
      const data = await response.json();
      setAiTutorResponse(data.reply || data.response || "I am processing your lessons. Feel free to ask another query!");
    } catch (err) {
      setAiTutorResponse("I processed your input! Newtonian mechanics and advanced calculus are fully calibrated. Try asking detailed curriculum queries.");
    } finally {
      setAiTutorLoading(false);
    }
  };

  // Run AI Study Planner
  const handleGeneratePlan = () => {
    setPlannerLoading(true);
    setTimeout(() => {
      const plans: Record<string, string[]> = {
        "HSC Board Exam": [
          "Week 1-3: Organic Chemistry master foundations & Physics electromagnetism review",
          "Week 4-6: Complete Higher Math integration modules & dynamic quiz iterations",
          "Week 7-9: Bengali literary structure breakdowns + English writing drill exercises",
          "Week 10-12: Full Board mock tests simulation & AI real-time flaw debugging"
        ],
        "BCS Preliminary Guide": [
          "Week 1-3: Bangladesh Geography, historical landmarks, and constitutional details",
          "Week 4-6: General Science high-weight questions & mathematical reasoning techniques",
          "Week 7-9: International affairs, global treaties, and comprehensive vocabulary",
          "Week 10-12: Speed trials, previous years prelim analysis, and model test sprints"
        ],
        "Full-Stack Web Dev": [
          "Week 1-3: Modern ES6 Javascript foundations, asynchronous concepts, and DOM mastery",
          "Week 4-6: React 19 architecture, component separation, custom hooks & Tailwind CSS",
          "Week 7-9: Express backend endpoints, middleware architectures, and Postgres layouts",
          "Week 10-12: Multi-tenant production builds, Dockerization pipelines, and Cloud deployments"
        ]
      };
      setPlannerSchedule(plans[plannerGoal] || plans["HSC Board Exam"]);
      setPlannerLoading(false);
    }, 800);
  };

  // Run AI Career Advisor (communicates with backend API)
  const handleCareerAdvise = async () => {
    if (!careerRole.trim()) return;
    setCareerLoading(true);
    setCareerAdvice("");
    try {
      const response = await fetch("/api/ai/career", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRole: careerRole, currentSkills: careerSkills })
      });
      const data = await response.json();
      setCareerAdvice(data.advice || data.reply || "Your optimized roadmap is complete.");
    } catch (err) {
      setCareerAdvice(`Roadmap to ${careerRole}:
1. Focus on standard system structures & algorithms.
2. Complete verified cert modules in database design.
3. Apply for global tech programs via EduVerse Affiliate Network.`);
    } finally {
      setCareerLoading(false);
    }
  };

  // Run AI Exam Generator (communicates with backend API)
  const handleGenerateExam = async () => {
    setExamLoading(true);
    setExamSubmitted(false);
    setExamAnswers({});
    try {
      const response = await fetch("/api/ai/exam-gen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: examTopic, difficulty: examDifficulty })
      });
      const data = await response.json();
      // If server returns structured quiz, use it, otherwise fallback to premium mock questions
      if (data.quiz && Array.isArray(data.quiz.questions)) {
        setExamQuestions(data.quiz.questions);
      } else {
        throw new Error("fallback");
      }
    } catch (err) {
      // Hardened Premium Mock Questions
      const mockQuestions = [
        {
          question: "Which of the following is correct regarding Newton's Third Law of Motion?",
          options: [
            "Action and reaction act on the same body",
            "Action and reaction act on different bodies simultaneously",
            "Action is greater than reaction under gravity",
            "Reaction precedes action in cosmic frames"
          ],
          correctIndex: 1
        },
        {
          question: "Which sector of Bangladesh contributes the highest percentage to national GDP?",
          options: [
            "Agriculture Sector",
            "Industrial Sector",
            "Service Sector",
            "Remittance Sector"
          ],
          correctIndex: 2
        },
        {
          question: "What is the primary purpose of the 'useEffect' cleanup function in React?",
          options: [
            "To re-render the screen immediately",
            "To unsubscribe or clean up active side effects before the component unmounts",
            "To load environment parameters securely",
            "To cache state variables within the local storage engine"
          ],
          correctIndex: 1
        }
      ];
      setExamQuestions(mockQuestions);
    } finally {
      setExamLoading(false);
    }
  };

  // Submit mock quiz answers
  const handleExamSubmit = () => {
    let score = 0;
    examQuestions.forEach((q, idx) => {
      if (examAnswers[idx] === q.correctIndex) {
        score++;
      }
    });
    setExamScore(score);
    setExamSubmitted(true);
  };

  // Verify Certificate Lookup via Optimized Backend API (Target <100ms response)
  const handleVerifyCertificate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchCertId.trim()) return;
    setCertLoading(true);
    setCertSearched(true);
    setCertResult(null);

    const startTime = performance.now();
    try {
      const res = await fetch(`/api/certificates/verify/${encodeURIComponent(searchCertId.trim())}`);
      const data = await res.json();
      const endTime = performance.now();
      console.log(`Certificate verified in ${(endTime - startTime).toFixed(2)}ms`);

      if (res.ok) {
        setCertResult(data);
      } else {
        setCertResult({ verified: false, error: data.error || "Certificate identifier not validated" });
      }
    } catch (err) {
      setCertResult({ verified: false, error: "Network validation latency. Ensure server is online." });
    } finally {
      setCertLoading(false);
    }
  };

  // Run initial state triggers
  useEffect(() => {
    handleGeneratePlan();
    handleCareerAdvise();
    handleGenerateExam();
  }, []);

  const successStories = [
    {
      name: "Tanjim Ahmed",
      achievement: "Got Chance in BUET CSE (Rank 42)",
      quote: "EduVerse AI's study planner and integrated admission preparation mock tests gave me the dynamic competitive edge I needed to tackle engineering math.",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150"
    },
    {
      name: "Sabrina Jahan",
      achievement: "Passed 45th BCS Preliminary",
      quote: "The chapter wise BCS testing suite generated by the AI modules allowed me to identify deep weaknesses in my international affairs scores.",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150"
    },
    {
      name: "Ariful Islam",
      achievement: "Full-Stack Software Engineer (Remote)",
      quote: "Going from a beginner to writing server endpoints with the modular curriculum on EduVerse launched my career in global web development.",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150"
    }
  ];

  const popularInstructors = [
    { name: "Dr. Rakib Hasan", role: "Physics & Engineering", institution: "Ph.D. from BUET", rating: "4.95", img: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150" },
    { name: "Kabir Hossain", role: "BCS Cadre Guide", institution: "Administration Cadre", rating: "4.88", img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150" },
    { name: "Zahidul Islam", role: "Senior Web Architect", institution: "Lead Tech Developer", rating: "4.92", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150" }
  ];

  const faqItems = [
    {
      q: "How does the AI Tutor help in Bangladesh's local curriculum?",
      a: "Our AI model is specifically grounded with regional textbook guidelines (NCTB) for Class 9-12 and BCS testing standards. It provides native explanation structures in Bengali and English, analyzes weak areas, and builds bespoke mock boards in under 100 milliseconds."
    },
    {
      q: "Are the certificates verified on a ledger?",
      a: "Yes. Every certificate issued on EduVerse AI comes with a unique cryptographic verification key. Anyone, including international employers or universities, can verify its status instantly using our public Certificate Verification portal."
    },
    {
      q: "How do parents track their children's weekly logs?",
      a: "Through our Parent Dashboard. Parents receive regular SMS updates, real-time metrics on completed lessons, study streak challenges, and detailed performance diagnostic logs on quizzes."
    },
    {
      q: "What is the scholarship program about?",
      a: "The EduVerse Stars Scholarship provides full financial sponsorships for premium tech skill courses. Students are selected based on academic merit, mock board rankings, and challenge completions within the app."
    }
  ];

  return (
    <div className="space-y-24 pb-24 text-slate-100">
      
      {/* ---------------------------------------------------------
          1. NAVIGATION BAR (Premium landing inline header helper)
          --------------------------------------------------------- */}
      <nav id="landing-navbar" className="sticky top-0 z-40 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8 py-3 bg-slate-950/70 backdrop-blur-xl border-b border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-violet-500/20">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <div>
            <span className="text-lg font-black tracking-tight bg-gradient-to-r from-violet-400 via-indigo-200 to-white bg-clip-text text-transparent">
              EduVerse <span className="text-violet-500">AI</span>
            </span>
            <span className="hidden sm:inline-block ml-2 text-[9px] font-mono tracking-widest text-violet-400 bg-violet-950/40 border border-violet-800/50 px-2 py-0.5 rounded-full uppercase">Enterprise</span>
          </div>
        </div>

        {/* Global Search inside Nav */}
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Courses, Mentors..."
            className="w-full rounded-full bg-slate-900/80 border border-white/10 pl-9 pr-4 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-all"
          />
        </div>

        {/* Action Anchor Links */}
        <div className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-400">
          <a href="#courses-catalog" className="hover:text-white transition-colors">Courses</a>
          <a href="#live-classes" className="hover:text-white transition-colors">Live Classes</a>
          <a href="#ai-showcase" className="hover:text-white transition-colors">AI Tutor</a>
          <a href="#scholarships" className="hover:text-white transition-colors">Scholarships</a>
          <a href="#community" className="hover:text-white transition-colors">Community</a>
          <a href="#faq" className="hover:text-white transition-colors">FAQs</a>
        </div>

        {/* Login & Register Buttons */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => { setAuthMode("login"); setAuthModalOpen(true); }}
            className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-white/5 transition-all"
          >
            Login
          </button>
          <button 
            onClick={() => { setAuthMode("register"); setAuthModalOpen(true); }}
            className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-indigo-500 text-xs font-bold text-white shadow-lg shadow-violet-500/20 hover:brightness-110 transition-all"
          >
            Register
          </button>
        </div>
      </nav>

      {/* ---------------------------------------------------------
          2. HERO SECTION (Dynamic glow backdrop, high-end copy)
          --------------------------------------------------------- */}
      <section id="hero" className="relative rounded-3xl bg-slate-900/40 border border-white/5 overflow-hidden px-6 py-20 sm:px-12 sm:py-28 lg:px-20 text-center lg:text-left shadow-[0_0_50px_-12px_rgba(139,92,246,0.15)]">
        {/* Neon Glow spots */}
        <div className="absolute top-0 right-1/4 h-72 w-72 bg-violet-600/10 blur-[120px] rounded-full"></div>
        <div className="absolute -bottom-10 -left-10 h-72 w-72 bg-indigo-600/15 blur-[120px] rounded-full"></div>
        
        <div className="relative max-w-5xl mx-auto lg:grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full bg-violet-950/50 px-3 py-1 text-xs font-semibold text-violet-300 border border-violet-500/20">
              <Sparkles className="h-3.5 w-3.5 text-violet-400 animate-pulse" />
              <span>Next-Gen NCTB, BCS, and Professional AI Environment</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
              The Future of Learning <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-white bg-clip-text text-transparent">
                Starts Here.
              </span>
            </h1>

            <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              AI-powered education for students, professionals, and future leaders. Seamlessly master academic boards, conquer the preliminary BCS exam, build remote engineering skills, and learn side-by-side with an active, dedicated AI copilot.
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4">
              <a 
                href="#courses-catalog" 
                className="px-6 py-3 rounded-xl bg-violet-600 text-xs font-bold text-white shadow-lg shadow-violet-500/30 hover:brightness-110 hover:-translate-y-0.5 transition-all flex items-center gap-2"
              >
                Start Learning <ArrowRight className="h-4 w-4" />
              </a>
              <a 
                href="#courses-catalog" 
                className="px-6 py-3 rounded-xl bg-slate-900 border border-white/10 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-850 transition-all"
              >
                Explore Courses
              </a>
              <a 
                href="#ai-showcase" 
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-violet-950/40 to-slate-950 border border-violet-500/20 text-xs font-bold text-violet-300 hover:text-violet-100 transition-all flex items-center gap-1.5"
              >
                <Zap className="h-3.5 w-3.5 text-violet-400" /> Try AI Tutor
              </a>
            </div>
          </div>

          {/* Interactive Hero Tech Visual */}
          <div className="hidden lg:col-span-5 relative lg:block">
            <div className="relative rounded-2xl bg-slate-950/80 p-5 border border-white/5 shadow-2xl backdrop-blur-xl">
              <div className="flex items-center justify-between pb-3 border-b border-white/5 text-[10px] text-slate-500 font-mono">
                <span>SYSTEM STATUS: CALIBRATED</span>
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
              </div>
              
              <div className="py-4 space-y-3 text-left">
                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-violet-950/20 border border-violet-500/10">
                  <Brain className="h-4 w-4 text-violet-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-violet-300">Active NCTB & BCS Engine</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">Real-time model trained with Board guidelines and public preliminary matrices.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-indigo-950/20 border border-indigo-500/10">
                  <Tv className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-indigo-300">Live Video Infrastructure</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">Adaptive 1080p stream fallback, automated screen sharing, and interactive polls.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-xl bg-slate-900 border border-white/5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-300">Public Security Ledger</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">Instant certificates verification mapped with optimized 100ms response lookup.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------
          3. STATISTICS SECTION (High fidelity cards)
          --------------------------------------------------------- */}
      <section id="statistics" className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: "Students Enrolled", value: "1.2M+", detail: "+24% Growth this month", icon: Users, color: "text-violet-400" },
          { label: "Courses Available", value: "450+", detail: "SSC, HSC, BCS, Skills", icon: BookOpen, color: "text-indigo-400" },
          { label: "Expert Instructors", value: "120+", detail: "BUET, BCS Cadres, Admins", icon: GraduationCap, color: "text-emerald-400" },
          { label: "Certificates Issued", value: "98,000+", detail: "Publicly verified", icon: Award, color: "text-amber-400" }
        ].map((stat, i) => {
          const IconComponent = stat.icon;
          return (
            <div key={i} className="group relative rounded-2xl bg-slate-900/60 p-6 border border-white/5 hover:border-white/10 transition-all text-center sm:text-left overflow-hidden">
              <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-all">
                <IconComponent className="h-16 w-16 text-slate-300" />
              </div>
              <div className="flex items-center justify-center sm:justify-start gap-3">
                <div className={`p-2 rounded-lg bg-slate-950 border border-white/5 ${stat.color}`}>
                  <IconComponent className="h-5 w-5" />
                </div>
                <span className="text-xs text-slate-400 font-medium">{stat.label}</span>
              </div>
              <div className="mt-4 text-2xl sm:text-3xl font-black text-white">{stat.value}</div>
              <p className="text-[10px] text-slate-500 mt-1 font-mono">{stat.detail}</p>
            </div>
          );
        })}
      </section>

      {/* ---------------------------------------------------------
          4. FEATURED CATEGORIES (Interactive filter buttons)
          --------------------------------------------------------- */}
      <section id="categories" className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Elite Target Sectors</h2>
          <p className="text-xs sm:text-sm text-slate-400">Select a specialized track to refine textbook courses, question patterns, and mentor guidelines immediately.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { name: "SSC Preparation", filter: "Academic", desc: "NCTB Curriculum Class 9-10", icon: GraduationCap },
            { name: "HSC Preparation", filter: "Academic", desc: "Science, Commerce & Humanities", icon: BookOpen },
            { name: "Admission Preparation", filter: "Admission", desc: "BUET, DU & Medical Engines", icon: Award },
            { name: "Government Jobs", filter: "Government", desc: "BCS Preliminary & Written Sprints", icon: ShieldCheck },
            { name: "Freelancing Track", filter: "Skills", desc: "High-income web dev & graphics", icon: Laptop },
            { name: "AI & Technology", filter: "Skills", desc: "Python, ML, Prompt Engineering", icon: Brain }
          ].map((cat, i) => {
            const Icon = cat.icon;
            const isActive = selectedCategory === cat.filter;
            return (
              <button
                key={i}
                onClick={() => setSelectedCategory(cat.filter)}
                className={`group text-left p-5 rounded-2xl border transition-all flex flex-col justify-between h-40 ${
                  isActive 
                    ? "bg-violet-950/30 border-violet-500 shadow-lg shadow-violet-500/10" 
                    : "bg-slate-900/40 border-white/5 hover:border-white/10 hover:bg-slate-900/80"
                }`}
              >
                <div className={`p-2.5 rounded-xl bg-slate-950 border border-white/5 ${isActive ? "text-violet-400" : "text-slate-400"}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-violet-400 transition-colors">{cat.name}</h4>
                  <p className="text-[10px] text-slate-500 mt-1 leading-normal line-clamp-2">{cat.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* ---------------------------------------------------------
          5. AI FEATURES SHOWCASE (Interactive simulations!)
          --------------------------------------------------------- */}
      <section id="ai-showcase" className="relative rounded-3xl bg-slate-900/30 border border-white/5 overflow-hidden p-6 sm:p-10 shadow-[0_0_50px_-12px_rgba(139,92,246,0.15)]">
        {/* Glow backdrop */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,rgba(99,102,241,0.08),transparent_50%)]"></div>
        
        <div className="relative space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 rounded-full bg-violet-950/40 px-2.5 py-0.5 text-[10px] font-semibold text-violet-300 border border-violet-500/20">
                <Sparkles className="h-3 w-3 text-violet-400" />
                <span>EduVerse AI Labs</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Interactive AI Suite</h2>
              <p className="text-xs text-slate-400">Experience our fully operational cloud AI modules instantly below.</p>
            </div>

            {/* Showcase Tabs */}
            <div className="flex flex-wrap gap-2">
              {[
                { id: "tutor", label: "AI Tutor", icon: Brain },
                { id: "planner", label: "AI Study Planner", icon: Calendar },
                { id: "career", label: "AI Career Advisor", icon: Compass },
                { id: "exam", label: "AI Exam Generator", icon: FileText }
              ].map((tab) => {
                const TabIcon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveAITab(tab.id as any)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 ${
                      activeAITab === tab.id
                        ? "bg-violet-600 text-white border-violet-500"
                        : "bg-slate-950 text-slate-400 border-white/5 hover:text-white"
                    }`}
                  >
                    <TabIcon className="h-3.5 w-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl bg-slate-950/80 p-6 border border-white/5 shadow-inner">
            <AnimatePresence mode="wait">
              
              {/* TAB 1: AI TUTOR SIMULATOR */}
              {activeAITab === "tutor" && (
                <motion.div
                  key="tutor"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                    <Brain className="h-4 w-4 text-violet-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">Ask AI Tutor anything</h3>
                      <p className="text-[10px] text-slate-500">Linked to our backend text models. Tutors NCTB classes and global skill frameworks.</p>
                    </div>
                  </div>

                  <form onSubmit={handleAiTutorSubmit} className="space-y-4">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={aiTutorQuery}
                        onChange={(e) => setAiTutorQuery(e.target.value)}
                        placeholder="Type standard study question, e.g. Explain photosynthesis in Bengali..."
                        className="flex-grow rounded-xl bg-slate-900 border border-white/5 px-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
                      />
                      <button
                        type="submit"
                        disabled={aiTutorLoading}
                        className="px-4 py-3 rounded-xl bg-violet-600 hover:bg-violet-500 font-bold text-xs text-white disabled:opacity-50 flex items-center gap-1"
                      >
                        {aiTutorLoading ? "Thinking..." : <SendHorizontal className="h-4 w-4" />}
                      </button>
                    </div>

                    {/* Pre-cooked prompt helpers */}
                    <div className="flex flex-wrap gap-2 text-[10px] text-slate-400 font-semibold">
                      <span>Quick Prompts:</span>
                      <button 
                        type="button"
                        onClick={() => setAiTutorQuery("Explain static friction with an real-life example in Bengali")}
                        className="bg-slate-900 hover:bg-slate-850 px-2 py-1 rounded border border-white/5 text-violet-400"
                      >
                        "Explain friction in Bengali"
                      </button>
                      <button 
                        type="button"
                        onClick={() => setAiTutorQuery("What are the major rivers in Bangladesh of BCS prelim importance?")}
                        className="bg-slate-900 hover:bg-slate-850 px-2 py-1 rounded border border-white/5 text-violet-400"
                      >
                        "Bangladesh Rivers (BCS)"
                      </button>
                    </div>

                    {aiTutorResponse && (
                      <div className="rounded-xl bg-violet-950/10 border border-violet-500/20 p-4 space-y-2">
                        <div className="text-[10px] text-violet-400 font-mono flex items-center gap-1.5">
                          <CheckCircle2 className="h-3.5 w-3.5" /> VERIFIED INSTRUCTOR AI AGENT
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">{aiTutorResponse}</p>
                      </div>
                    )}
                  </form>
                </motion.div>
              )}

              {/* TAB 2: AI STUDY PLANNER */}
              {activeAITab === "planner" && (
                <motion.div
                  key="planner"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                    <Calendar className="h-4 w-4 text-violet-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">Dynamic Study Planner</h3>
                      <p className="text-[10px] text-slate-500">Input study goals and time frames to dynamically calibrate week-by-week NCTB or Skills syllabi.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1.5 uppercase font-mono">Select Target Goal</label>
                      <select 
                        value={plannerGoal}
                        onChange={(e) => setPlannerGoal(e.target.value)}
                        className="w-full rounded-xl bg-slate-900 border border-white/5 px-3 py-2 text-xs text-white"
                      >
                        <option value="HSC Board Exam">HSC Board Exam</option>
                        <option value="BCS Preliminary Guide">BCS Preliminary Guide</option>
                        <option value="Full-Stack Web Dev">Full-Stack Web Dev</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1.5 uppercase font-mono">Timeline Duration</label>
                      <select 
                        value={plannerWeeks}
                        onChange={(e) => setPlannerWeeks(e.target.value)}
                        className="w-full rounded-xl bg-slate-900 border border-white/5 px-3 py-2 text-xs text-white"
                      >
                        <option value="4 Weeks">4 Weeks Crash</option>
                        <option value="8 Weeks">8 Weeks Accelerated</option>
                        <option value="12 Weeks">12 Weeks Thorough</option>
                      </select>
                    </div>

                    <div className="flex items-end">
                      <button
                        onClick={handleGeneratePlan}
                        disabled={plannerLoading}
                        className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white flex items-center justify-center gap-1.5"
                      >
                        <Sparkles className="h-3.5 w-3.5" /> {plannerLoading ? "Calculating..." : "Calibrate Schedule"}
                      </button>
                    </div>
                  </div>

                  {plannerSchedule.length > 0 && (
                    <div className="space-y-2 pt-2">
                      <h4 className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Your Personalized Milestones:</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {plannerSchedule.map((step, idx) => (
                          <div key={idx} className="p-3.5 rounded-xl bg-slate-900 border border-white/5 hover:border-violet-500/20 transition-all flex gap-3">
                            <span className="h-5 w-5 rounded-full bg-violet-950 border border-violet-800/40 text-[10px] font-bold text-violet-400 flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <span className="text-xs text-slate-300 leading-relaxed">{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {/* TAB 3: AI CAREER ADVISOR */}
              {activeAITab === "career" && (
                <motion.div
                  key="career"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                    <Compass className="h-4 w-4 text-violet-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">AI Career Roadmap Advisor</h3>
                      <p className="text-[10px] text-slate-500">Query optimal tech career maps and certification tracks mapped against global outsourcing and tech hub demands.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1 font-mono">Target Professional Role</label>
                      <input
                        type="text"
                        value={careerRole}
                        onChange={(e) => setCareerRole(e.target.value)}
                        placeholder="e.g. Machine Learning Engineer"
                        className="w-full rounded-xl bg-slate-900 border border-white/5 px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-500 mb-1 font-mono">Your Current Skillset</label>
                      <input
                        type="text"
                        value={careerSkills}
                        onChange={(e) => setCareerSkills(e.target.value)}
                        placeholder="e.g. Python basics, college physics"
                        className="w-full rounded-xl bg-slate-900 border border-white/5 px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleCareerAdvise}
                    disabled={careerLoading}
                    className="py-2.5 px-5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white flex items-center gap-1.5"
                  >
                    <Compass className="h-4 w-4" /> {careerLoading ? "Assessing global job maps..." : "Generate Roadmap"}
                  </button>

                  {careerAdvice && (
                    <div className="rounded-xl bg-indigo-950/15 border border-indigo-500/20 p-4">
                      <div className="text-[10px] text-indigo-400 font-mono mb-2 uppercase tracking-wide">Dynamic Professional Diagnostic Advice:</div>
                      <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">{careerAdvice}</p>
                    </div>
                  )}
                </motion.div>
              )}

              {/* TAB 4: AI EXAM GENERATOR */}
              {activeAITab === "exam" && (
                <motion.div
                  key="exam"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                    <FileText className="h-4 w-4 text-violet-400" />
                    <div>
                      <h3 className="text-sm font-bold text-white">Dynamic Board and BCS Exam Generator</h3>
                      <p className="text-[10px] text-slate-500">Instantly fetch authentic standard multi-choice questions with customized difficulty scales.</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <div>
                      <select
                        value={examTopic}
                        onChange={(e) => setExamTopic(e.target.value)}
                        className="rounded-xl bg-slate-900 border border-white/5 px-3.5 py-2 text-xs text-white"
                      >
                        <option value="English Grammar">English Grammar (HSC)</option>
                        <option value="BCS General Science">BCS General Science</option>
                        <option value="Newtonian Physics">Physics Mechanics</option>
                      </select>
                    </div>

                    <div>
                      <select
                        value={examDifficulty}
                        onChange={(e) => setExamDifficulty(e.target.value)}
                        className="rounded-xl bg-slate-900 border border-white/5 px-3.5 py-2 text-xs text-white"
                      >
                        <option value="Easy">Easy Level</option>
                        <option value="Medium">Medium Level</option>
                        <option value="Hard">Hard Board Level</option>
                      </select>
                    </div>

                    <button
                      onClick={handleGenerateExam}
                      disabled={examLoading}
                      className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white"
                    >
                      {examLoading ? "Formulating questions..." : "Generate Test"}
                    </button>
                  </div>

                  {examQuestions.length > 0 && !examSubmitted && (
                    <div className="space-y-4 pt-2">
                      {examQuestions.map((q, qIdx) => (
                        <div key={qIdx} className="space-y-2 p-3 bg-slate-900 rounded-xl border border-white/5">
                          <span className="text-[10px] text-slate-500 font-mono font-bold block">QUESTION {qIdx + 1}:</span>
                          <p className="text-xs font-semibold text-slate-200">{q.question}</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                            {q.options.map((opt: string, oIdx: number) => (
                              <button
                                key={oIdx}
                                type="button"
                                onClick={() => setExamAnswers(prev => ({ ...prev, [qIdx]: oIdx }))}
                                className={`text-left text-xs p-2.5 rounded-lg border transition-all ${
                                  examAnswers[qIdx] === oIdx 
                                    ? "bg-violet-950/40 border-violet-500 text-white" 
                                    : "bg-slate-950 border-white/5 text-slate-400 hover:text-white"
                                }`}
                              >
                                {opt}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}

                      <button
                        onClick={handleExamSubmit}
                        className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-xs text-white"
                      >
                        Submit Answers
                      </button>
                    </div>
                  )}

                  {examSubmitted && (
                    <div className="rounded-xl bg-emerald-950/20 border border-emerald-500/20 p-5 text-center space-y-3">
                      <CheckCircle2 className="h-10 w-10 text-emerald-400 mx-auto" />
                      <h4 className="text-sm font-bold text-white">Assessment Submitted Successfully!</h4>
                      <div className="text-2xl font-black text-emerald-400">
                        Score: {examScore} / {examQuestions.length} ({Math.round((examScore / examQuestions.length) * 100)}%)
                      </div>
                      <p className="text-xs text-slate-400">XP points, performance metrics, and streak status have been updated on your account.</p>
                      <button
                        onClick={() => setExamSubmitted(false)}
                        className="px-4 py-2 rounded-lg bg-slate-900 border border-white/5 text-xs text-slate-300 hover:text-white font-bold"
                      >
                        Retake Test
                      </button>
                    </div>
                  )}
                </motion.div>
              )}

            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------
          6. TRENDING COURSES (With interactive enroll syllabus link)
          --------------------------------------------------------- */}
      <section id="courses-catalog" className="space-y-8 scroll-mt-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-violet-400 uppercase tracking-widest font-mono">
              <TrendingUp className="h-4 w-4" /> Hot Masterclasses
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1">Trending Course Programs</h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">Acquire state-of-the-art expertise under direct supervision of elite guides.</p>
          </div>

          {/* Inline Filters list */}
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                  selectedCategory === cat
                    ? "bg-violet-600 text-white border-violet-500"
                    : "bg-slate-900 text-slate-400 border-white/5 hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Courses grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course) => {
            const isEnrolled = enrolledCourseIds.includes(course.id);
            return (
              <div
                key={course.id}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl bg-slate-900/60 border border-white/5 hover:border-violet-500/30 transition-all shadow-md"
              >
                <div>
                  <div className="relative h-44 w-full overflow-hidden bg-slate-950">
                    <img
                      src={course.image}
                      alt={course.title}
                      className="h-full w-full object-cover group-hover:scale-105 transition-all duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 rounded-full bg-slate-950/80 px-2.5 py-1 text-[9px] font-bold text-violet-300 border border-violet-500/20 uppercase tracking-widest font-mono">
                      {course.subcategory}
                    </div>
                  </div>

                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5 text-slate-500" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-1 text-amber-400">
                        <Star className="h-3.5 w-3.5 fill-amber-400" />
                        <span>{course.rating.toFixed(1)}</span>
                      </div>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-violet-400 transition-colors line-clamp-1">
                      {course.title}
                    </h3>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {course.description}
                    </p>

                    <div className="text-xs text-slate-500 font-mono">
                      Instructor: <span className="text-slate-300 font-sans">{course.instructorName}</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0 flex items-center justify-between mt-4">
                  <div className="text-base font-black text-white">
                    {course.price > 0 ? `${course.price} BDT` : "Free Access"}
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => onViewCourse(course)}
                      className="px-3 py-1.5 rounded-lg border border-white/5 hover:bg-white/5 text-xs font-semibold text-slate-300 hover:text-white transition-all flex items-center gap-1"
                    >
                      <Play className="h-3 w-3" /> Syllabus
                    </button>
                    
                    {isEnrolled ? (
                      <button
                        onClick={() => onViewCourse(course)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-800/30 text-xs font-bold text-emerald-400 hover:bg-emerald-900/40 transition-all"
                      >
                        Enrolled
                      </button>
                    ) : (
                      <button
                        onClick={() => onEnroll(course.id)}
                        className="px-3 py-1.5 rounded-lg bg-violet-600 text-xs font-bold text-white shadow-md hover:brightness-110 transition-all"
                      >
                        Enroll
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-12 rounded-2xl bg-slate-900/40 border border-white/5">
            <span className="text-sm text-slate-400">No matches found for "{searchQuery}". Try updating filters.</span>
          </div>
        )}
      </section>

      {/* ---------------------------------------------------------
          7. LIVE CLASSES SECTION (Simulator shortcuts)
          --------------------------------------------------------- */}
      <section id="live-classes" className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
              <h3 className="text-xl font-bold text-white">Active Live Learning Studios</h3>
            </div>
            <p className="text-xs text-slate-400">Enter virtual rooms featuring interactive whiteboard simulation, collaborative audio streaming, and live polls.</p>
          </div>

          <div className="space-y-4">
            {liveSessions.map((session) => (
              <div
                key={session.id}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-5 rounded-2xl bg-slate-900/40 border border-white/5 hover:border-white/10 transition-all gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider ${
                      session.status === "live" ? "bg-red-950 text-red-400 border border-red-800/30" : "bg-blue-950 text-blue-400 border border-blue-800/30"
                    }`}>
                      {session.status}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">Topic: {session.category}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{session.title}</h4>
                  <p className="text-xs text-slate-400">Educator: {session.instructorName} • {session.enrolledCount} active viewers</p>
                </div>

                <button
                  onClick={() => onViewLive(session)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-950 border border-white/5 hover:border-violet-500 hover:bg-slate-900 text-xs font-bold text-slate-300 hover:text-white transition-all"
                >
                  Join Stream
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Custom sidebar banner for interactive classes */}
        <div className="rounded-2xl bg-gradient-to-br from-violet-950/30 to-indigo-950/20 border border-violet-500/10 p-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="p-3.5 rounded-full bg-slate-950 border border-white/5 w-fit text-violet-400">
              <Tv className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-white">Why Live Classrooms?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              We do not just host standard webinars. Our Live studios include active whiteboard replication synced with real-time feedback loops. Learn and solve challenging problems alongside top board evaluators.
            </p>
          </div>
          
          <div className="pt-4 border-t border-white/5 mt-4 flex items-center justify-between text-[11px] text-violet-300 font-mono font-bold">
            <span>STUDIO CAPACITY: 10K+ / POD</span>
            <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> 98% Uplink</span>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------
          8. SUCCESS STORIES (Chronicles Carousel/Masonry)
          --------------------------------------------------------- */}
      <section id="success-stories" className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-1">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Student Success Chronicles</h2>
          <p className="text-xs sm:text-sm text-slate-400">Get inspired by real local candidates securing top ranks using our specialized AI planners.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {successStories.map((story, i) => (
            <div key={i} className="group relative rounded-2xl bg-slate-900/40 border border-white/5 p-6 space-y-4 hover:bg-slate-900/80 transition-all flex flex-col justify-between">
              <p className="text-xs text-slate-300 italic leading-relaxed">
                "{story.quote}"
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <img
                  src={story.avatar}
                  alt={story.name}
                  className="h-10 w-10 rounded-full object-cover border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h5 className="text-xs font-bold text-white">{story.name}</h5>
                  <p className="text-[10px] text-violet-400 font-medium">{story.achievement}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------------
          9. TOP INSTRUCTORS (Mentor Showcase)
          --------------------------------------------------------- */}
      <section id="instructors" className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 max-w-5xl mx-auto">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Meet Your Elite Guides</h2>
            <p className="text-xs text-slate-400 mt-1">Direct support from BUET PhDs, active civil service Guide leaders, and industry veterans.</p>
          </div>
          <a href="#courses-catalog" className="text-xs font-bold text-violet-400 hover:text-violet-300 flex items-center gap-1">
            Browse Classes <ChevronRight className="h-4 w-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {popularInstructors.map((ins, i) => (
            <div key={i} className="rounded-2xl bg-slate-900/40 border border-white/5 p-5 flex items-center gap-4 hover:border-violet-500/20 transition-all">
              <img
                src={ins.img}
                alt={ins.name}
                className="h-12 w-12 rounded-full object-cover border border-white/10 shrink-0"
              />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">{ins.name}</h4>
                <p className="text-xs text-slate-400 font-medium">{ins.role}</p>
                <div className="text-[9px] font-mono text-slate-500">{ins.institution}</div>
              </div>
              <div className="ml-auto flex items-center gap-0.5 text-amber-400 text-xs font-bold font-mono">
                <Star className="h-3 w-3 fill-amber-400" />
                <span>{ins.rating}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------------
          10. COMMUNITY LEARNING SECTION (Forum preview)
          --------------------------------------------------------- */}
      <section id="community" className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-mono text-violet-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
              <Users className="h-4 w-4" /> Collaborative Boards
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mt-1">Active Community Learning</h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">Co-operate with over a million registered scholars discussing tricky items.</p>
          </div>

          <button 
            onClick={() => alert("Please click 'Community' in the top global navigation header to participate in our verified discussion boards.")}
            className="px-4 py-2 rounded-xl bg-slate-900 border border-white/5 hover:border-violet-500 text-xs font-bold text-slate-300 hover:text-white transition-all flex items-center gap-1.5"
          >
            <Plus className="h-4 w-4" /> Start Discussion Thread
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { title: "What are the most frequent NCTB Class 9 physics questions for board exams?", author: "Rahat", replies: 14, category: "Academic" },
            { title: "Strategy for BCS preliminary international affairs section?", author: "Farhana", replies: 28, category: "Government" },
            { title: "MERN Stack or NextJS 15? Which technology should a beginner learn?", author: "Zamil", replies: 42, category: "Skills" },
            { title: "How to apply for the fully sponsored EduVerse Stars Scholarship program?", author: "Afsana", replies: 19, category: "Scholarships" }
          ].map((thread, idx) => (
            <div key={idx} className="p-5 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-white/10 transition-all flex justify-between items-start">
              <div className="space-y-2">
                <span className="px-2 py-0.5 rounded text-[8px] font-mono bg-violet-950/40 text-violet-300 border border-violet-800/30 font-bold uppercase tracking-wider">{thread.category}</span>
                <h4 className="text-xs sm:text-sm font-semibold text-slate-200 hover:text-violet-400 cursor-pointer line-clamp-1">{thread.title}</h4>
                <p className="text-[10px] text-slate-500">Initiated by {thread.author} • {thread.replies} responses</p>
              </div>
              <span className="text-[10px] text-violet-400 font-mono font-bold bg-violet-950/40 px-2 py-1 rounded">HOT</span>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------------
          11. CERTIFICATES AND VERIFICATION (Instant lookup!)
          --------------------------------------------------------- */}
      <section id="scholarships" className="relative rounded-3xl bg-slate-900/40 border border-white/5 p-6 sm:p-10 shadow-[0_0_50px_-12px_rgba(139,92,246,0.15)]">
        <div className="absolute top-0 right-0 h-40 w-40 bg-violet-600/10 blur-[80px] rounded-full"></div>
        
        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Certificate mock visual */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative rounded-2xl bg-slate-950 border border-white/10 p-5 shadow-2xl space-y-4">
              <div className="flex justify-between items-start border-b border-white/5 pb-3">
                <div>
                  <span className="text-[9px] font-mono tracking-widest text-violet-400 uppercase">EDUVERSE ACCREDITATION</span>
                  <h4 className="text-xs font-black text-white">CERTIFICATE OF EXCELLENCE</h4>
                </div>
                <Award className="h-7 w-7 text-amber-400 animate-pulse" />
              </div>

              <div className="space-y-2 text-center py-4">
                <p className="text-[10px] text-slate-500">PROUDLY PRESENTED TO</p>
                <h3 className="text-base font-extrabold text-white bg-gradient-to-r from-violet-300 to-indigo-200 bg-clip-text text-transparent">Tanjim Ahmed</h3>
                <p className="text-[10px] text-slate-400">For successful syllabus mastery of Class 9 Academic Science Curriculum</p>
              </div>

              <div className="flex justify-between items-end text-[8px] font-mono text-slate-500 border-t border-white/5 pt-3">
                <div>
                  <div>ID: EV-CERT-740219</div>
                  <div>ISSUED: JULY 2026</div>
                </div>
                <div className="h-10 w-10 bg-white p-0.5 rounded">
                  <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=EV-CERT-740219" alt="Verification QR" className="h-full w-full" />
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 order-1 lg:order-2 space-y-5">
            <div className="inline-flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-800/30 px-2.5 py-0.5 rounded-full font-bold">
              <ShieldCheck className="h-3.5 w-3.5" /> SECURE PUBLIC LEDGER LOOKUP
            </div>
            
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Public Certificate Verification Portal</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              We have migrated off local-only searches. This verification search connects directly to our optimized backend route targeting sub-100 millisecond response speeds. Anyone can check qualification status instantly.
            </p>

            <form onSubmit={handleVerifyCertificate} className="space-y-4">
              <div className="flex gap-2 max-w-md">
                <input
                  type="text"
                  value={searchCertId}
                  onChange={(e) => setSearchCertId(e.target.value)}
                  placeholder="Enter Certificate ID, e.g. EV-CERT-740219..."
                  className="flex-grow rounded-xl bg-slate-900 border border-white/5 px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500"
                />
                <button
                  type="submit"
                  disabled={certLoading}
                  className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white disabled:opacity-50"
                >
                  {certLoading ? "Verifying..." : "Query Key"}
                </button>
              </div>

              {certSearched && certResult && (
                <div className={`rounded-xl p-4 max-w-md border ${
                  certResult.verified ? "bg-emerald-950/10 border-emerald-500/20" : "bg-red-950/10 border-red-500/20"
                }`}>
                  {certResult.verified ? (
                    <div className="space-y-1.5">
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                        <CheckCircle2 className="h-4 w-4" /> CERTIFICATE VALIDATED
                      </div>
                      <p className="text-[11px] text-slate-300">
                        Course ID: <span className="text-white font-semibold">{certResult.certificate.courseId}</span> <br />
                        Accreditation ID: <span className="text-white font-semibold">{certResult.certificate.id}</span>
                      </p>
                    </div>
                  ) : (
                    <div className="text-xs font-bold text-red-400 flex items-center gap-1.5">
                      <Info className="h-4 w-4" /> {certResult.error || "No matching credential in database ledger."}
                    </div>
                  )}
                </div>
              )}
            </form>
          </div>

        </div>
      </section>

      {/* ---------------------------------------------------------
          12. MOBILE APP PROMOTION (App mockup + QR)
          --------------------------------------------------------- */}
      <section id="mobile-app" className="rounded-3xl bg-gradient-to-br from-indigo-950/20 to-slate-900/60 border border-white/5 p-8 sm:p-12 overflow-hidden relative">
        <div className="absolute top-1/2 left-1/4 h-64 w-64 bg-violet-600/10 blur-[90px] rounded-full -translate-y-1/2"></div>
        
        <div className="relative max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-4 max-w-lg text-center md:text-left">
            <span className="text-[9px] font-mono tracking-widest text-violet-400 font-bold bg-violet-950/40 border border-violet-800/30 px-3 py-1 rounded-full uppercase">Download mobile companion</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">EduVerse AI On The Go</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Never interrupt your learning momentum. Take lessons offline, participate in instant notifications, access regional language translations natively, and converse with the voice-enabled AI tutor without high data overhead.
            </p>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-2">
              <button onClick={() => alert("Mobile companion download dispatched!")} className="px-4 py-2 rounded-xl bg-slate-950 border border-white/5 hover:border-violet-500 transition-all text-xs text-slate-200 font-bold flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-violet-400" /> Play Store
              </button>
              <button onClick={() => alert("Mobile companion download dispatched!")} className="px-4 py-2 rounded-xl bg-slate-950 border border-white/5 hover:border-violet-500 transition-all text-xs text-slate-200 font-bold flex items-center gap-2">
                <Laptop className="h-4 w-4 text-indigo-400" /> App Store
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-2xl border border-white/10 shrink-0 shadow-lg">
            <div className="h-16 w-16 bg-white p-1 rounded">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://ai.studio/build" alt="App Download QR" className="h-full w-full" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Scan to Download</h4>
              <p className="text-[10px] text-slate-500 mt-0.5">Compatible with iOS 16+ & Android 12+</p>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------
          13. FAQ SECTION (Smooth Accordion)
          --------------------------------------------------------- */}
      <section id="faq" className="max-w-4xl mx-auto space-y-8 scroll-mt-20">
        <div className="text-center space-y-1">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">Frequently Asked Questions</h2>
          <p className="text-xs sm:text-sm text-slate-400">Everything you need to know about the EduVerse platform.</p>
        </div>

        <div className="space-y-3">
          {faqItems.map((item, idx) => {
            const isOpen = openFAQIndex === idx;
            return (
              <div key={idx} className="rounded-xl bg-slate-900/40 border border-white/5 overflow-hidden transition-all">
                <button
                  onClick={() => setOpenFAQIndex(isOpen ? null : idx)}
                  className="w-full text-left p-5 flex justify-between items-center text-xs sm:text-sm font-bold text-white hover:bg-white/5 transition-all"
                >
                  <span>{item.q}</span>
                  <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                </button>
                {isOpen && (
                  <div className="p-5 pt-0 text-xs text-slate-400 leading-relaxed border-t border-white/5 bg-slate-950/20">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ---------------------------------------------------------
          14. NEWSLETTER SUBSCRIPTION (With success toast)
          --------------------------------------------------------- */}
      <section id="newsletter" className="max-w-3xl mx-auto text-center rounded-3xl bg-slate-900/60 p-8 sm:p-12 border border-white/5 shadow-[0_0_50px_-12px_rgba(139,92,246,0.1)] space-y-6">
        <Mail className="h-8 w-8 text-violet-400 mx-auto animate-bounce" />
        <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">Subscribe to EduVerse Dispatch</h2>
        <p className="text-xs text-slate-400 max-w-md mx-auto">Receive board revisions patterns, upcoming scholarship slots, and high-quality tech guides right in your mail weekly.</p>
        
        {newsletterSubscribed ? (
          <div className="text-xs font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-800/30 px-4 py-2.5 rounded-xl max-w-sm mx-auto">
            ✓ Successfully Subscribed! Check your mailbox soon.
          </div>
        ) : (
          <form 
            onSubmit={(e) => { e.preventDefault(); if (newsletterEmail.trim()) setNewsletterSubscribed(true); }}
            className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto"
          >
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Input your primary mail..."
              className="flex-grow rounded-xl bg-slate-950 border border-white/5 px-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
            />
            <button type="submit" className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white shadow shadow-violet-500/20">
              Subscribe
            </button>
          </form>
        )}
      </section>

      {/* ---------------------------------------------------------
          15. FOOTER (Detailed, Enterprise links)
          --------------------------------------------------------- */}
      <footer className="border-t border-white/5 pt-12 pb-6 space-y-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="col-span-2 md:col-span-1 space-y-3">
            <span className="text-base font-black tracking-tight text-white">EduVerse AI</span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Global online learning ecosystem for Bangladesh. Empowering next-generation candidates across national academic syllabi and professional tracks.
            </p>
            <div className="flex gap-3 text-slate-500">
              <a href="https://github.com" className="hover:text-white transition-colors"><Github className="h-4 w-4" /></a>
              <a href="#" className="hover:text-white transition-colors"><Mail className="h-4 w-4" /></a>
              <a href="#" className="hover:text-white transition-colors"><Info className="h-4 w-4" /></a>
            </div>
          </div>

          {/* Academic Paths */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[10px] text-violet-400">Academic Paths</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">Class 9 NCTB Modules</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">Class 10 Board prep</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">HSC Science Track</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">HSC Commerce Track</a></li>
            </ul>
          </div>

          {/* Careers & Skills */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[10px] text-indigo-400">Skills Track</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">Web Development</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">Python & Machine Learning</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">UX Design Fundamentals</a></li>
              <li><a href="#courses-catalog" className="hover:text-white transition-colors">Global Freelancing</a></li>
            </ul>
          </div>

          {/* Help & Trust */}
          <div className="space-y-3 text-xs">
            <h4 className="font-bold text-white uppercase tracking-wider text-[10px] text-emerald-400">Trust & Security</h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><a href="#faq" className="hover:text-white transition-colors">Public LEDGER verify</a></li>
              <li><a href="#scholarships" className="hover:text-white transition-colors">Scholarships criteria</a></li>
              <li><a href="#faq" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#faq" className="hover:text-white transition-colors">Privacy Shield Policy</a></li>
            </ul>
          </div>

        </div>

        {/* Dynamic Legal & Port notation */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/5 pt-6 text-[10px] text-slate-500 font-mono">
          <span>© 2026 EduVerse AI. All rights reserved.</span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" /> SECURED BY SSL & JWT SCHEMES
          </span>
        </div>
      </footer>

      {/* ---------------------------------------------------------
          AUTHENTICATION SIMULATOR MODAL (Role access control showcase)
          --------------------------------------------------------- */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-white/10 p-6 space-y-4 shadow-2xl">
            
            {/* Header */}
            <div className="flex justify-between items-center pb-2 border-b border-white/5">
              <div className="space-y-1">
                <span className="text-[9px] font-mono tracking-widest text-violet-400 uppercase">SECURE PORTAL</span>
                <h3 className="text-sm sm:text-base font-black text-white">
                  {authMode === "login" ? "Sign In to EduVerse" : "Create Enterprise Account"}
                </h3>
              </div>
              <button 
                onClick={() => setAuthModalOpen(false)}
                className="text-slate-500 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {/* Success message */}
            {authSuccessMsg && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/20 rounded-xl text-xs text-emerald-400 text-center font-semibold">
                {authSuccessMsg}
              </div>
            )}

            {/* Auth Form / 2FA flow */}
            {!twoFactorRequired ? (
              <form onSubmit={handleAuthSubmit} className="space-y-3.5">
                <div>
                  <label className="block text-[10px] text-slate-500 font-mono mb-1">EMAIL ADDRESS</label>
                  <input
                    type="email"
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="student@eduverse.com"
                    className="w-full rounded-xl bg-slate-950 border border-white/5 px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 font-mono mb-1">PASSWORD</label>
                  <input
                    type="password"
                    required
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl bg-slate-950 border border-white/5 px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
                  />
                </div>

                {authMode === "register" && (
                  <div>
                    <label className="block text-[10px] text-slate-500 font-mono mb-1.5">INITIAL ACCESS ROLE</label>
                    <div className="grid grid-cols-2 gap-1.5 text-xs">
                      {["Student", "Parent", "Instructor"].map((role) => (
                        <span key={role} className="p-2 bg-slate-950 border border-white/5 rounded-lg text-slate-300 text-[11px] text-center font-bold">
                          {role}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white shadow shadow-violet-500/20"
                >
                  {authMode === "login" ? "Verify Credentials" : "Initialize Account"}
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => setAuthMode(authMode === "login" ? "register" : "login")}
                    className="text-[10px] text-slate-500 hover:text-slate-300"
                  >
                    {authMode === "login" ? "Need an enterprise account? Register" : "Already have an account? Login"}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleMfaSubmit} className="space-y-4">
                <div className="bg-violet-950/30 p-3 rounded-xl border border-violet-500/15 text-xs text-violet-300 leading-normal">
                  🔐 **Two-Factor Authentication (MFA) Activated**: We detected a login request. A one-time verification token has been dispatched. Enter any 6 digit code (e.g. `123456`) to authorize.
                </div>

                <div>
                  <label className="block text-[10px] text-slate-500 font-mono mb-1">ENTER 6-DIGIT MFA PIN</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value)}
                    placeholder="e.g. 123456"
                    className="w-full rounded-xl bg-slate-950 border border-white/5 px-3.5 py-2 text-xs text-center font-mono text-white placeholder-slate-600 focus:outline-none focus:border-violet-500 tracking-widest text-lg"
                  />
                </div>

                <button
                  type="submit"
                  disabled={mfaSuccess}
                  className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white"
                >
                  {mfaSuccess ? "Verifying Token..." : "Validate Token"}
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
