import React, { useState } from "react";
import { MessageSquare, Cpu, ShieldAlert, Award, Calendar, Zap, Sparkles, Send, GraduationCap, Globe2, Loader2, ArrowRight } from "lucide-react";

interface AICopilotProps {
  onSendMessage: (msg: string) => Promise<{ text: string }>;
  onGenerateQuiz: (topic: string, difficulty: string) => Promise<{ questions: any[] }>;
  onGetCareerAdvice: (targetRole: string, currentSkills: string) => Promise<{ text: string }>;
  onTranslateText: (text: string, targetLanguage: string) => Promise<{ text: string }>;
}

export default function AICopilot({
  onSendMessage,
  onGenerateQuiz,
  onGetCareerAdvice,
  onTranslateText
}: AICopilotProps) {
  const [activeSubTab, setActiveSubTab] = useState<"tutor" | "exam" | "career" | "translate">("tutor");

  // AI Tutor states
  const [tutorMessage, setTutorMessage] = useState("");
  const [tutorChat, setTutorChat] = useState<{ role: "user" | "ai"; text: string }[]>([
    { role: "ai", text: "Assalamu Alaikum! I am your EduVerse AI Personal Tutor. I can explain Newtonian Mechanics, debug React apps, write BCS Bengali literature reviews, or translate essays. Ask me anything!" }
  ]);
  const [loadingTutor, setLoadingTutor] = useState(false);

  // Exam Generator states
  const [examTopic, setExamTopic] = useState("Physics Mechanics");
  const [examDifficulty, setExamDifficulty] = useState("Medium");
  const [generatedQuizQuestions, setGeneratedQuizQuestions] = useState<any[]>([]);
  const [loadingExam, setLoadingExam] = useState(false);
  const [quizSelectedAnswers, setQuizSelectedAnswers] = useState<{ [key: string]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Career Advisor states
  const [targetRole, setTargetRole] = useState("BUET Computer Science Graduate");
  const [currentSkills, setCurrentSkills] = useState("Basic Math, Grade 12 Calculus");
  const [careerResult, setCareerResult] = useState("");
  const [loadingCareer, setLoadingCareer] = useState(false);

  // Translation states
  const [translationInput, setTranslationInput] = useState("আমার সোনার বাংলা, আমি তোমায় ভালোবাসি।");
  const [translationLanguage, setTranslationLanguage] = useState("English");
  const [translationResult, setTranslationResult] = useState("");
  const [loadingTranslation, setLoadingTranslation] = useState(false);

  // AI Tutor submission
  const handleTutorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tutorMessage.trim()) return;
    const userMsg = tutorMessage;
    setTutorChat((prev) => [...prev, { role: "user", text: userMsg }]);
    setTutorMessage("");
    setLoadingTutor(true);

    try {
      const res = await onSendMessage(userMsg);
      setTutorChat((prev) => [...prev, { role: "ai", text: res.text }]);
    } catch (err) {
      setTutorChat((prev) => [...prev, { role: "ai", text: "Sorry, I had an issue fetching from server. Please retry." }]);
    } finally {
      setLoadingTutor(false);
    }
  };

  // Exam Generator submission
  const handleGenerateExam = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingExam(true);
    setQuizSelectedAnswers({});
    setQuizSubmitted(false);
    setGeneratedQuizQuestions([]);

    try {
      const res = await onGenerateQuiz(examTopic, examDifficulty);
      setGeneratedQuizQuestions(res.questions || []);
    } catch (err) {
      alert("Failed to generate custom quiz questions. Try again.");
    } finally {
      setLoadingExam(false);
    }
  };

  const handleQuizOptionClick = (idx: number, oIdx: number) => {
    setQuizSelectedAnswers({ ...quizSelectedAnswers, [idx]: oIdx });
  };

  const handleQuizGrade = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 0;
    generatedQuizQuestions.forEach((q, i) => {
      if (quizSelectedAnswers[i] === q.correctAnswerIndex) {
        score++;
      }
    });
    setQuizScore(score);
    setQuizSubmitted(true);
  };

  // Career Advisor submission
  const handleCareerAdvisor = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingCareer(true);
    setCareerResult("");

    try {
      const res = await onGetCareerAdvice(targetRole, currentSkills);
      setCareerResult(res.text || "");
    } catch (err) {
      setCareerResult("Failed to obtain advisory comments. Please retry.");
    } finally {
      setLoadingCareer(false);
    }
  };

  // Translation submission
  const handleTranslate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!translationInput.trim()) return;
    setLoadingTranslation(true);
    setTranslationResult("");

    try {
      const res = await onTranslateText(translationInput, translationLanguage);
      setTranslationResult(res.text || "");
    } catch (err) {
      setTranslationResult("Translation query failed.");
    } finally {
      setLoadingTranslation(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 pb-20">
      
      {/* Sub tabs list navigation sidebar */}
      <div className="space-y-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <Cpu className="h-5 w-5 text-violet-400 animate-pulse" />
            <span className="font-extrabold text-sm text-white">AI Research Laboratory</span>
          </div>
          
          <div className="flex flex-col gap-1 text-xs">
            <button
              onClick={() => setActiveSubTab("tutor")}
              className={`p-3 rounded-xl border text-left font-bold transition-all flex items-center gap-2 ${
                activeSubTab === "tutor"
                  ? "bg-violet-950/40 text-violet-300 border-violet-800"
                  : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
              }`}
            >
              <MessageSquare className="h-4 w-4" />
              AI Intelligent Tutor
            </button>

            <button
              onClick={() => setActiveSubTab("exam")}
              className={`p-3 rounded-xl border text-left font-bold transition-all flex items-center gap-2 ${
                activeSubTab === "exam"
                  ? "bg-violet-950/40 text-violet-300 border-violet-800"
                  : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
              }`}
            >
              <Award className="h-4 w-4" />
              AI Exam Generator
            </button>

            <button
              onClick={() => setActiveSubTab("career")}
              className={`p-3 rounded-xl border text-left font-bold transition-all flex items-center gap-2 ${
                activeSubTab === "career"
                  ? "bg-violet-950/40 text-violet-300 border-violet-800"
                  : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
              }`}
            >
              <GraduationCap className="h-4 w-4" />
              AI Career Advisor
            </button>

            <button
              onClick={() => setActiveSubTab("translate")}
              className={`p-3 rounded-xl border text-left font-bold transition-all flex items-center gap-2 ${
                activeSubTab === "translate"
                  ? "bg-violet-950/40 text-violet-300 border-violet-800"
                  : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
              }`}
            >
              <Globe2 className="h-4 w-4" />
              AI Translation System
            </button>
          </div>
        </div>
      </div>

      {/* Main interactive dynamic viewport column */}
      <div className="lg:col-span-3">
        
        {/* TAB 1: AI TUTOR */}
        {activeSubTab === "tutor" && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 min-h-[460px] flex flex-col justify-between">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                <Sparkles className="h-4.5 w-4.5 text-violet-400" />
                EduVerse Personal AI Tutor
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Powered by Gemini on the server. Ask complex physics questions, demand programming snippets, or ask to summarize academic notes.
              </p>
            </div>

            {/* Chat list viewport */}
            <div className="flex-grow my-6 p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-4 overflow-y-auto max-h-[260px] text-xs">
              {tutorChat.map((chat, i) => (
                <div key={i} className={`flex ${chat.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`p-3 rounded-2xl max-w-md leading-relaxed whitespace-pre-wrap border ${
                    chat.role === "user"
                      ? "bg-violet-600 border-violet-500 text-white rounded-tr-none"
                      : "bg-slate-900 border-slate-800 text-slate-300 rounded-tl-none"
                  }`}>
                    {chat.text}
                  </div>
                </div>
              ))}

              {loadingTutor && (
                <div className="flex justify-start">
                  <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin text-violet-400" />
                    <span>Tutor is formulating concepts...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Chat send input */}
            <form onSubmit={handleTutorSubmit} className="flex gap-2">
              <input
                type="text"
                placeholder="Explain the substitution rule in Calculus limits with an example..."
                value={tutorMessage}
                onChange={(e) => setTutorMessage(e.target.value)}
                className="flex-grow rounded-xl bg-slate-950 px-4 py-3 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
              />
              <button
                type="submit"
                disabled={loadingTutor || !tutorMessage.trim()}
                className="rounded-xl bg-violet-600 px-5 text-xs font-bold text-white hover:brightness-110 disabled:opacity-50 flex items-center gap-1.5"
              >
                <Send className="h-4 w-4" /> Send
              </button>
            </form>
          </div>
        )}

        {/* TAB 2: EXAM GENERATOR */}
        {activeSubTab === "exam" && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 min-h-[460px] space-y-6">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">AI Instant MCQ Exam Generator</h3>
              <p className="text-xs text-slate-400">Generate high-fidelity quiz questions on any customized academic topic dynamically.</p>
            </div>

            <form onSubmit={handleGenerateExam} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-slate-400 font-bold">Topic</label>
                <input
                  type="text"
                  value={examTopic}
                  onChange={(e) => setExamTopic(e.target.value)}
                  placeholder="e.g. BCS Bangladesh Geography"
                  className="w-full rounded-lg bg-slate-950 px-3 py-2.5 text-white border border-slate-800 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-bold">Difficulty</label>
                <select
                  value={examDifficulty}
                  onChange={(e) => setExamDifficulty(e.target.value)}
                  className="w-full rounded-lg bg-slate-950 px-3 py-2.5 text-white border border-slate-800 focus:outline-none"
                >
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  disabled={loadingExam}
                  className="w-full rounded-lg bg-violet-600 py-2.5 font-bold text-white hover:brightness-110 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  {loadingExam ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Generating...
                    </>
                  ) : (
                    "Generate Questions"
                  )}
                </button>
              </div>
            </form>

            {/* Generated Quiz questions list rendering */}
            {generatedQuizQuestions.length > 0 && (
              <form onSubmit={handleQuizGrade} className="space-y-4 text-xs p-5 rounded-xl bg-slate-950 border border-slate-850">
                <div className="font-bold text-slate-300 border-b border-slate-800 pb-2">Custom generated mock quiz:</div>

                {generatedQuizQuestions.map((q, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="font-bold text-slate-200">{idx + 1}. {q.question}</div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt: string, oIdx: number) => {
                        const isSelected = quizSelectedAnswers[idx] === oIdx;
                        const isCorrectAnswer = q.correctAnswerIndex === oIdx;
                        
                        let optionStyle = "bg-slate-900 border-slate-800/80 text-slate-400 hover:text-slate-300";
                        if (isSelected) optionStyle = "bg-violet-950/40 border-violet-800 text-violet-300 font-bold";
                        if (quizSubmitted && isCorrectAnswer) optionStyle = "bg-emerald-950/40 border-emerald-800 text-emerald-400 font-bold";

                        return (
                          <div
                            key={oIdx}
                            onClick={() => !quizSubmitted && handleQuizOptionClick(idx, oIdx)}
                            className={`p-2.5 rounded border text-[11px] font-semibold cursor-pointer transition-all ${optionStyle}`}
                          >
                            {opt}
                          </div>
                        );
                      })}
                    </div>

                    {quizSubmitted && (
                      <div className="text-[10px] text-slate-500 leading-snug mt-1">
                        <span className="font-bold text-slate-400 block">Explanation:</span> {q.explanation}
                      </div>
                    )}
                  </div>
                ))}

                {quizSubmitted ? (
                  <div className="text-center p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                    <div className="text-lg font-black text-white">Score: {quizScore} / {generatedQuizQuestions.length}</div>
                    <span className="text-[10px] text-slate-500">Perfect studying! Generate another chapter set above.</span>
                  </div>
                ) : (
                  <button
                    type="submit"
                    disabled={Object.keys(quizSelectedAnswers).length < generatedQuizQuestions.length}
                    className="w-full rounded-xl bg-violet-600 py-3 font-bold text-white shadow-md hover:brightness-110 disabled:opacity-50 transition-all"
                  >
                    Grade Quiz
                  </button>
                )}
              </form>
            )}
          </div>
        )}

        {/* TAB 3: CAREER ADVISOR */}
        {activeSubTab === "career" && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 min-h-[460px] space-y-6">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">AI Career Advisory & Path Planner</h3>
              <p className="text-xs text-slate-400">Examine current skill sets and design targeted pathways for high-demand careers in BUET engineering, medical, or government roles.</p>
            </div>

            <form onSubmit={handleCareerAdvisor} className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Target Career Goal</label>
                <input
                  type="text"
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value)}
                  placeholder="e.g. BCS Administration Cadre"
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-300 font-bold">Your Current Skills</label>
                <input
                  type="text"
                  value={currentSkills}
                  onChange={(e) => setCurrentSkills(e.target.value)}
                  placeholder="e.g. Basic Math, fluent English writing"
                  className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loadingCareer}
                className="sm:col-span-2 w-full rounded-xl bg-violet-600 py-3 font-bold text-white hover:brightness-110 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loadingCareer ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Evaluating Gaps...
                  </>
                ) : (
                  "Generate Custom Learning Roadmap"
                )}
              </button>
            </form>

            {careerResult && (
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-850 text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                {careerResult}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: TRANSLATION SYSTEM */}
        {activeSubTab === "translate" && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 min-h-[460px] space-y-6">
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">AI Language Translation System</h3>
              <p className="text-xs text-slate-400">Effortlessly translate essays and notes between Bengali and English dynamically.</p>
            </div>

            <form onSubmit={handleTranslate} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1.5">
                  <label className="text-slate-300 font-bold">Source Text</label>
                  <input
                    type="text"
                    value={translationInput}
                    onChange={(e) => setTranslationInput(e.target.value)}
                    className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-300 font-bold">Target Language</label>
                  <select
                    value={translationLanguage}
                    onChange={(e) => setTranslationLanguage(e.target.value)}
                    className="w-full rounded-lg bg-slate-950 px-3.5 py-2.5 text-white border border-slate-800 focus:outline-none"
                  >
                    <option value="English">English</option>
                    <option value="Bengali">Bengali</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={loadingTranslation || !translationInput.trim()}
                className="w-full rounded-xl bg-violet-600 py-2.5 font-bold text-white hover:brightness-110 disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {loadingTranslation ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Translating...
                  </>
                ) : (
                  "Translate Now"
                )}
              </button>
            </form>

            {translationResult && (
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-850 space-y-1 text-xs">
                <span className="text-[10px] text-slate-500 font-mono">Translation output:</span>
                <p className="font-extrabold text-white text-sm">{translationResult}</p>
              </div>
            )}
          </div>
        )}

      </div>

    </div>
  );
}
