import React, { useState } from "react";
import { Play, Pause, ChevronRight, FileText, CheckCircle, Award, AwardIcon, Volume2, FastForward } from "lucide-react";
import { Course, Lesson, Quiz } from "../types";

interface CourseViewerProps {
  course: Course;
  completedLessonIds: string[];
  onMarkLessonComplete: (lessonId: string) => void;
  onSubmitQuiz: (courseId: string, score: number, totalQuestions: number) => void;
}

export default function CourseViewer({
  course,
  completedLessonIds,
  onMarkLessonComplete,
  onSubmitQuiz
}: CourseViewerProps) {
  const [activeLesson, setActiveLesson] = useState<Lesson>(course.lessons[0] || null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState("1.0x");
  const [notesInput, setNotesInput] = useState("");
  const [savedNotes, setSavedNotes] = useState<string[]>([]);
  
  // Quiz evaluation state
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [userAnswers, setUserAnswers] = useState<{ [questionId: string]: number }>({});
  const [score, setScore] = useState(0);

  const activeQuiz: Quiz | undefined = course.quizzes?.[0];

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notesInput.trim()) return;
    setSavedNotes([...savedNotes, notesInput]);
    setNotesInput("");
  };

  const handleSelectAnswer = (qId: string, optIdx: number) => {
    setUserAnswers({ ...userAnswers, [qId]: optIdx });
  };

  const handleQuizSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeQuiz) return;

    let correctCount = 0;
    activeQuiz.questions.forEach((q) => {
      if (userAnswers[q.id] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    setScore(correctCount);
    setQuizSubmitted(true);
    
    // Fire callback back to parent / state
    onSubmitQuiz(course.id, correctCount, activeQuiz.questions.length);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20">
      
      {/* Video Stream & Notes Section */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Simulated Video Player */}
        <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden group shadow-2xl">
          <div className="absolute inset-0 flex items-center justify-center">
            {isPlaying ? (
              <div className="text-center space-y-2 animate-pulse">
                <FastForward className="h-10 w-10 text-violet-500 mx-auto" />
                <span className="text-xs text-slate-400 font-mono">Streaming in HD at {playbackSpeed}</span>
              </div>
            ) : (
              <button
                onClick={() => setIsPlaying(true)}
                className="h-16 w-16 rounded-full bg-violet-600 flex items-center justify-center text-white shadow-lg hover:scale-105 transition-all"
              >
                <Play className="h-7 w-7 fill-white ml-1" />
              </button>
            )}
          </div>

          {/* Player controls overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between opacity-100 group-hover:opacity-100 transition-opacity">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-white hover:text-violet-400 transition-colors"
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              </button>
              <div className="text-xs text-slate-300 font-mono">
                {activeLesson ? activeLesson.title : "Syllabus Introductory Block"}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                {["1.0x", "1.25x", "1.5x", "2.0x"].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => setPlaybackSpeed(speed)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      playbackSpeed === speed ? "bg-violet-600 text-white" : "bg-slate-900 text-slate-400 hover:text-white"
                    }`}
                  >
                    {speed}
                  </button>
                ))}
              </div>
              <Volume2 className="h-4 w-4 text-slate-400" />
            </div>
          </div>
        </div>

        {/* Lesson descriptions & Action */}
        {activeLesson && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <span className="text-[10px] text-slate-500 font-mono">Active Lesson Detail</span>
                <h3 className="text-base font-bold text-white mt-1">{activeLesson.title}</h3>
                <p className="text-xs text-slate-400 mt-1">{activeLesson.notes || "This lesson covers fundamental theoretical parameters."}</p>
              </div>

              <button
                onClick={() => onMarkLessonComplete(activeLesson.id)}
                disabled={completedLessonIds.includes(activeLesson.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  completedLessonIds.includes(activeLesson.id)
                    ? "bg-emerald-950/40 text-emerald-400 border border-emerald-800/40"
                    : "bg-violet-600 text-white hover:brightness-110"
                }`}
              >
                {completedLessonIds.includes(activeLesson.id) ? "✓ Completed (+100 XP)" : "Mark Complete"}
              </button>
            </div>
          </div>
        )}

        {/* Study Note Scratchpad */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h4 className="text-sm font-bold text-slate-100">Interactive study scratchpad</h4>
          <p className="text-xs text-slate-400">Save private thoughts and bullet points during active streams.</p>

          <form onSubmit={handleSaveNote} className="flex gap-2">
            <input
              type="text"
              placeholder="Type your lecture notes..."
              value={notesInput}
              onChange={(e) => setNotesInput(e.target.value)}
              className="flex-grow rounded-lg bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
            />
            <button className="rounded-lg bg-violet-600 px-4 text-xs font-bold text-white hover:brightness-110">
              Save
            </button>
          </form>

          {savedNotes.length > 0 && (
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {savedNotes.map((note, i) => (
                <div key={i} className="p-2 rounded bg-slate-950 text-xs text-slate-300 border border-slate-850">
                  {note}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Curriculum list & quizzes */}
      <div className="space-y-6">
        
        {/* Lessons checklist sidebar */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <h4 className="text-sm font-bold text-white">Course Syllabus Index</h4>
          
          <div className="space-y-2">
            {course.lessons.map((lesson) => {
              const active = activeLesson?.id === lesson.id;
              const completed = completedLessonIds.includes(lesson.id);

              return (
                <div
                  key={lesson.id}
                  onClick={() => {
                    setActiveLesson(lesson);
                    setIsPlaying(false);
                  }}
                  className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                    active 
                      ? "bg-violet-950/30 border-violet-800/60 text-violet-300" 
                      : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {completed ? (
                      <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                    ) : (
                      <div className="h-4 w-4 rounded-full border border-slate-700 shrink-0"></div>
                    )}
                    <span className="truncate max-w-[160px]">{lesson.title}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 shrink-0">{lesson.duration}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chapter Quiz Assessment */}
        {activeQuiz && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Award className="h-4 w-4 text-amber-500" />
              Chapter Quiz Assessment
            </h4>
            <p className="text-xs text-slate-400">Score 80%+ to generate verified credentials instantly.</p>

            {quizSubmitted ? (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 text-center space-y-3">
                <span className="font-mono text-[10px] text-slate-500 uppercase tracking-wide">Test Complete</span>
                <div className="text-2xl font-black text-white">
                  Score: {score} / {activeQuiz.questions.length}
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {score >= (activeQuiz.questions.length * 0.8)
                    ? "Congratulations! You passed with high marks. Certificate successfully generated and saved to your portal profiles."
                    : "Keep studying and retry when ready. Practice makes perfect."}
                </p>
                <button
                  onClick={() => {
                    setQuizSubmitted(false);
                    setUserAnswers({});
                  }}
                  className="rounded-lg bg-slate-900 px-3.5 py-1.5 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white hover:border-slate-700 transition-all"
                >
                  Retry Quiz
                </button>
              </div>
            ) : (
              <form onSubmit={handleQuizSubmit} className="space-y-4 text-xs">
                {activeQuiz.questions.map((q) => (
                  <div key={q.id} className="p-3 rounded-lg bg-slate-950 border border-slate-850 space-y-2">
                    <div className="font-bold text-slate-200 leading-snug">{q.question}</div>
                    
                    <div className="space-y-1.5">
                      {q.options.map((opt, oIdx) => (
                        <div
                          key={oIdx}
                          onClick={() => handleSelectAnswer(q.id, oIdx)}
                          className={`p-2 rounded border text-[11px] font-semibold cursor-pointer transition-all ${
                            userAnswers[q.id] === oIdx
                              ? "bg-violet-950/40 border-violet-800 text-violet-300 font-bold"
                              : "bg-slate-900 border-slate-800/80 text-slate-400 hover:text-slate-300"
                          }`}
                        >
                          {opt}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <button
                  type="submit"
                  disabled={Object.keys(userAnswers).length < activeQuiz.questions.length}
                  className="w-full rounded-xl bg-violet-600 py-2.5 font-bold text-white shadow-md hover:brightness-110 disabled:opacity-50 transition-all"
                >
                  Submit Quiz Answers
                </button>
              </form>
            )}
          </div>
        )}

      </div>

    </div>
  );
}
