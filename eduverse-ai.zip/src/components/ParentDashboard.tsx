import React from "react";
import { User, Activity, Calendar, Receipt, Award, Star, CheckCircle, ShieldAlert } from "lucide-react";
import { User as UserType, Certificate, Transaction } from "../types";

interface ParentDashboardProps {
  currentUser: UserType;
  certificates: Certificate[];
  transactions: Transaction[];
}

export default function ParentDashboard({
  currentUser,
  certificates,
  transactions
}: ParentDashboardProps) {
  // Mock linked student progress details
  const childName = "Rafid Rahman";
  const childLevel = 4;
  const childXP = 2450;
  const childCompletedLessons = 3;

  const quizGrades = [
    { subject: "Mechanics Chapter Test", date: "July 2026", score: "90%", status: "Passed", badge: "Quiz Whiz" },
    { subject: "JavaScript ES6 Foundations Quiz", date: "June 2026", score: "85%", status: "Passed", badge: "First Steps" }
  ];

  return (
    <div className="space-y-10 pb-20">
      
      {/* Linked Child Profile Overview */}
      <section className="p-6 rounded-2xl bg-gradient-to-r from-violet-950/20 to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-violet-600/20 ring-2 ring-violet-500/40 text-violet-400">
            <User className="h-7 w-7" />
          </div>
          <div>
            <div className="text-xs text-slate-400 font-mono">Linked Student Profile</div>
            <h3 className="text-lg font-black text-white">{childName}</h3>
            <p className="text-xs text-slate-300">Level {childLevel} • {childXP} XP Accumulated</p>
          </div>
        </div>

        {/* Quick analytics info */}
        <div className="flex items-center gap-6 text-xs text-slate-300">
          <div className="space-y-1">
            <span className="text-slate-500 font-bold uppercase tracking-wider block text-[10px]">Total attended lessons</span>
            <span className="text-lg font-extrabold text-white">{childCompletedLessons} Classes</span>
          </div>
          <div className="h-8 w-px bg-slate-800"></div>
          <div className="space-y-1">
            <span className="text-slate-500 font-bold uppercase tracking-wider block text-[10px]">Academic Streak</span>
            <span className="text-lg font-extrabold text-amber-500">5 Days Active</span>
          </div>
        </div>
      </section>

      {/* Main Grid: Attendance & Grades vs Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Academic Performance Reports */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Activity className="h-5 w-5 text-violet-400" />
            Chapter quiz performance reports
          </h3>

          <div className="space-y-4">
            {quizGrades.map((grade, i) => (
              <div key={i} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-slate-100">{grade.subject}</h4>
                  <p className="text-[10px] text-slate-400">Date completed: {grade.date}</p>
                </div>

                <div className="flex items-center gap-4 text-xs">
                  <div className="text-right">
                    <div className="font-extrabold text-emerald-400 text-sm">{grade.score}</div>
                    <span className="text-[10px] rounded bg-emerald-950 px-2 py-0.5 font-bold text-emerald-400 uppercase tracking-wide">
                      {grade.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Attendance Tracker Visual Calendar */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="h-4 w-4 text-indigo-400" />
              Simulated Weekly Attendance Calendar
            </h3>
            <p className="text-xs text-slate-400">Shows daily logins, homework submission completions, and study streaks.</p>

            <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => {
                const active = i < 5; // First 5 days active
                return (
                  <div key={day} className="space-y-2">
                    <span className="text-slate-500 text-[10px] uppercase font-bold">{day}</span>
                    <div className={`h-10 rounded-lg border flex items-center justify-center transition-all ${
                      active 
                        ? "bg-violet-950/40 border-violet-800/60 text-violet-300 shadow shadow-violet-500/10" 
                        : "bg-slate-950 border-slate-850 text-slate-600"
                    }`}>
                      {active ? "✓" : "—"}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Sidebar: Parent Payment History & Receipts */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Receipt className="h-4 w-4 text-emerald-400" />
              Child Subscription & Invoice logs
            </h3>
            
            <div className="space-y-3">
              {transactions.map((txn) => (
                <div key={txn.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 space-y-1">
                  <div className="flex justify-between text-xs font-bold text-slate-200">
                    <span className="truncate">{txn.courseTitle}</span>
                    <span className="text-emerald-400 font-mono shrink-0">{txn.amount} BDT</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>ID: {txn.id}</span>
                    <span>Status: {txn.status}</span>
                  </div>
                </div>
              ))}

              {transactions.length === 0 && (
                <div className="p-4 rounded-xl bg-slate-950/40 border border-dashed border-slate-800 text-center text-xs text-slate-500">
                  No billing transactions logged yet. Enable Course Purchases in Admin settings to simulate live checkouts.
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
