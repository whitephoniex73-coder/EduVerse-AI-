-- EduVerse AI Enterprise PostgreSQL Database Schema
-- Production Ready & Optimized for millions of rows

-- Enable UUID extension for secure, non-sequential resource identifiers
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Define custom enum for User Roles
CREATE TYPE user_role AS ENUM (
  'Student', 'Parent', 'Teacher', 'Instructor', 'Mentor', 
  'Content Creator', 'Affiliate Partner', 'Moderator', 'Admin', 'Super Admin'
);

-- Define custom enum for Transaction Gateways
CREATE TYPE payment_gateway AS ENUM (
  'bKash', 'Nagad', 'Rocket', 'SSLCommerz', 'Stripe', 'PayPal'
);

-- Define custom enum for Transaction Status
CREATE TYPE payment_status AS ENUM (
  'pending', 'completed', 'failed'
);

-- Define custom enum for Live Session Status
CREATE TYPE live_status AS ENUM (
  'upcoming', 'live', 'ended'
);

-- ---------------------------------------------------------
-- 1. USERS TABLE (Supports soft-deletes and streak/level logs)
-- ---------------------------------------------------------
CREATE TABLE users (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'usr_' || uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'Student',
  parent_id VARCHAR(100) NULL,
  xp INTEGER DEFAULT 0 CHECK (xp >= 0),
  streak INTEGER DEFAULT 0 CHECK (streak >= 0),
  level INTEGER DEFAULT 1 CHECK (level >= 1),
  badges TEXT[] DEFAULT '{}',
  last_active TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
  
  -- Foreign Key Constraint (Parent Linkage)
  CONSTRAINT fk_user_parent FOREIGN KEY (parent_id) 
    REFERENCES users(id) ON DELETE SET NULL
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_parent ON users(parent_id) WHERE parent_id IS NOT NULL;


-- ---------------------------------------------------------
-- 2. COURSES TABLE
-- ---------------------------------------------------------
CREATE TABLE courses (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'c_' || uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  subcategory VARCHAR(100) NOT NULL,
  instructor_id VARCHAR(100) NOT NULL,
  price NUMERIC(10, 2) DEFAULT 0.00 CHECK (price >= 0.00),
  rating NUMERIC(3, 2) DEFAULT 5.00 CHECK (rating BETWEEN 0.00 AND 5.00),
  duration VARCHAR(50) DEFAULT '10 hours',
  students_enrolled INTEGER DEFAULT 0 CHECK (students_enrolled >= 0),
  image_url VARCHAR(512) NOT NULL,
  is_popular BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,

  CONSTRAINT fk_courses_instructor FOREIGN KEY (instructor_id) 
    REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_courses_category ON courses(category);
CREATE INDEX idx_courses_subcategory ON courses(subcategory);


-- ---------------------------------------------------------
-- 3. LESSONS TABLE
-- ---------------------------------------------------------
CREATE TABLE lessons (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'l_' || uuid_generate_v4(),
  course_id VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  duration VARCHAR(50) NOT NULL,
  video_url VARCHAR(512) NULL,
  pdf_url VARCHAR(512) NULL,
  notes TEXT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_lessons_course FOREIGN KEY (course_id) 
    REFERENCES courses(id) ON DELETE CASCADE
);

CREATE INDEX idx_lessons_course ON lessons(course_id);


-- ---------------------------------------------------------
-- 4. ENROLLMENTS TABLE (N-to-N User-Course linkage)
-- ---------------------------------------------------------
CREATE TABLE enrollments (
  user_id VARCHAR(100) NOT NULL,
  course_id VARCHAR(100) NOT NULL,
  enrolled_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (user_id, course_id),
  CONSTRAINT fk_enrollments_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_enrollments_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);


-- ---------------------------------------------------------
-- 5. COMPLETED LESSONS TABLE (Tracking watch logs)
-- ---------------------------------------------------------
CREATE TABLE completed_lessons (
  user_id VARCHAR(100) NOT NULL,
  lesson_id VARCHAR(100) NOT NULL,
  completed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (user_id, lesson_id),
  CONSTRAINT fk_completed_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_completed_lesson FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
);


-- ---------------------------------------------------------
-- 6. CERTIFICATES TABLE (Unique Accreditation Keys)
-- ---------------------------------------------------------
CREATE TABLE certificates (
  id VARCHAR(100) PRIMARY KEY, -- standard EV-CERT-XXXXXX
  course_id VARCHAR(100) NOT NULL,
  student_id VARCHAR(100) NOT NULL,
  issued_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  qr_code_url VARCHAR(512) NOT NULL,

  CONSTRAINT fk_certificates_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  CONSTRAINT fk_certificates_student FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Fast Index for Certificate public lookup <100ms
CREATE UNIQUE INDEX idx_certificates_lookup ON certificates(id);


-- ---------------------------------------------------------
-- 7. TRANSACTIONS TABLE (Payment Ledgers)
-- ---------------------------------------------------------
CREATE TABLE transactions (
  id VARCHAR(100) PRIMARY KEY, -- standard TXN-XXXXXX
  user_id VARCHAR(100) NOT NULL,
  course_id VARCHAR(100) NOT NULL,
  amount NUMERIC(10, 2) NOT NULL CHECK (amount >= 0.00),
  currency VARCHAR(10) DEFAULT 'BDT',
  gateway payment_gateway NOT NULL DEFAULT 'bKash',
  status payment_status NOT NULL DEFAULT 'pending',
  coupon_code VARCHAR(50) NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_transactions_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE RESTRICT
);

CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_status ON transactions(status);


-- ---------------------------------------------------------
-- 8. DISCUSSION FORUM POSTS & REPLIES
-- ---------------------------------------------------------
CREATE TABLE forum_posts (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'post_' || uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  author_id VARCHAR(100) NOT NULL,
  upvotes INTEGER DEFAULT 0 CHECK (upvotes >= 0),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_forum_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE forum_replies (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'reply_' || uuid_generate_v4(),
  post_id VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  author_id VARCHAR(100) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_replies_post FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
  CONSTRAINT fk_replies_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_forum_posts_category ON forum_posts(category);


-- ---------------------------------------------------------
-- 9. LIVE CLASS SESSIONS
-- ---------------------------------------------------------
CREATE TABLE live_sessions (
  id VARCHAR(100) PRIMARY KEY DEFAULT 'live_' || uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  instructor_id VARCHAR(100) NOT NULL,
  scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
  status live_status NOT NULL DEFAULT 'upcoming',
  enrolled_count INTEGER DEFAULT 0 CHECK (enrolled_count >= 0),
  whiteboard_data TEXT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_live_instructor FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_live_scheduled ON live_sessions(scheduled_at);
