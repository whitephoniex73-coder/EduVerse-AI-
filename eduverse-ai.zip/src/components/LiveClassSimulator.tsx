import React, { useState, useRef, useEffect } from "react";
import { Play, Send, Check, Monitor, MonitorUp, Vote, Edit2, Eraser } from "lucide-react";
import { LiveSession, User } from "../types";

interface LiveClassSimulatorProps {
  session: LiveSession;
  currentUser: User;
  onVotePoll: (sessionId: string, pollId: string, optionIdx: number) => void;
  onSendChatMessage: (sessionId: string, message: string) => void;
}

export default function LiveClassSimulator({
  session,
  currentUser,
  onVotePoll,
  onSendChatMessage
}: LiveClassSimulatorProps) {
  const [chatInput, setChatInput] = useState("");
  const [screenSharing, setScreenSharing] = useState(false);
  const [activeColor, setActiveColor] = useState("#8b5cf6"); // Violet

  // Whiteboard Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Reset whiteboard
    ctx.fillStyle = "#0f172a"; // Slate-900 background
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = activeColor;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearWhiteboard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChatMessage(session.id, chatInput);
    setChatInput("");
  };

  const activePoll = session.polls?.[0];
  const hasVoted = activePoll ? activePoll.votedUsers[currentUser.id] !== undefined : false;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-20">
      
      {/* Live Stream Viewport & Whiteboard */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Stream viewport / screen share */}
        <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl flex flex-col justify-between p-5">
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
              <span className="text-xs font-bold text-white tracking-wide uppercase">Live Class Broadcast</span>
            </div>
            
            <button
              onClick={() => setScreenSharing(!screenSharing)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 ${
                screenSharing
                  ? "bg-violet-950/40 border-violet-800 text-violet-300"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              {screenSharing ? <Monitor className="h-4 w-4" /> : <MonitorUp className="h-4 w-4" />}
              {screenSharing ? "Screen Sharing Active" : "Mock Screen Share"}
            </button>
          </div>

          <div className="text-center space-y-2 py-10">
            {screenSharing ? (
              <div className="p-8 rounded-xl bg-slate-900/90 max-w-sm mx-auto border border-slate-800/80 text-xs text-slate-300 space-y-2">
                <Monitor className="h-10 w-10 text-violet-400 mx-auto animate-bounce" />
                <span className="font-bold text-white block">Sharing Desktop Window #1</span>
                <span className="text-[10px] text-slate-500 font-mono">Presenting slide formulas & homework files to students.</span>
              </div>
            ) : (
              <div className="p-8 rounded-xl bg-slate-900/90 max-w-sm mx-auto border border-slate-800/80 text-xs text-slate-300 space-y-2">
                <div className="h-12 w-12 rounded-full bg-violet-600/20 text-violet-400 flex items-center justify-center mx-auto ring-2 ring-violet-500/30">
                  <Play className="h-6 w-6 fill-violet-400" />
                </div>
                <span className="font-bold text-white block">Educator Camera Video Feed</span>
                <span className="text-slate-400 block">{session.instructorName} is currently discussing mechanics problems.</span>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
            <span>Adaptive bitrate: HD 1080p</span>
            <span>Total Attendees: {session.enrolledCount}</span>
          </div>
        </div>

        {/* Interactive Whiteboard drawer */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Edit2 className="h-4 w-4 text-violet-400" />
                Collaborative Interactive Whiteboard
              </h4>
              <p className="text-xs text-slate-400">Click and drag below to solve problems collaboratively with classmates.</p>
            </div>
            
            <button
              onClick={clearWhiteboard}
              className="px-2.5 py-1 rounded bg-slate-950 border border-slate-850 hover:border-red-800 text-[10px] text-slate-400 hover:text-red-400 font-bold tracking-tight transition-colors flex items-center gap-1"
            >
              <Eraser className="h-3 w-3" /> Clear Board
            </button>
          </div>

          {/* Canvas Drawer */}
          <canvas
            ref={canvasRef}
            width={600}
            height={220}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            className="w-full h-56 rounded-xl border border-slate-800 bg-slate-950 cursor-crosshair"
          />

          {/* Drawing Tool Settings */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mr-2">Marker colors:</span>
            {[
              { label: "Violet", color: "#8b5cf6" },
              { label: "Emerald", color: "#10b981" },
              { label: "Rose", color: "#f43f5e" },
              { label: "White", color: "#ffffff" }
            ].map((tool) => (
              <button
                key={tool.color}
                onClick={() => setActiveColor(tool.color)}
                className={`h-6 w-6 rounded-full transition-all flex items-center justify-center ${
                  activeColor === tool.color ? "ring-2 ring-slate-300 ring-offset-2 ring-offset-slate-900Scale" : ""
                }`}
                style={{ backgroundColor: tool.color }}
                title={tool.label}
              />
            ))}
          </div>
        </div>

      </div>

      {/* Live Polling System & Classroom Chats */}
      <div className="space-y-6">
        
        {/* Polling System */}
        {activePoll && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Vote className="h-4 w-4 text-violet-400" />
              Classroom Live Poll
            </h4>
            
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-3">
              <div className="text-xs font-bold text-slate-200 leading-snug">{activePoll.question}</div>
              
              <div className="space-y-2">
                {activePoll.options.map((opt, index) => {
                  const totalVotes = activePoll.votes.reduce((a, b) => a + b, 0);
                  const optionVotes = activePoll.votes[index];
                  const percentage = totalVotes > 0 ? Math.round((optionVotes / totalVotes) * 100) : 0;

                  return (
                    <div key={index} className="space-y-1">
                      {hasVoted ? (
                        <div className="relative p-2.5 rounded bg-slate-900 border border-slate-800 text-xs overflow-hidden flex justify-between items-center">
                          {/* Vote percentage background bar */}
                          <div className="absolute top-0 bottom-0 left-0 bg-violet-950/30 transition-all" style={{ width: `${percentage}%` }}></div>
                          <span className="relative z-10 text-slate-300">{opt}</span>
                          <span className="relative z-10 text-[10px] font-mono text-slate-400 font-bold">{percentage}% ({optionVotes})</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => onVotePoll(session.id, activePoll.id, index)}
                          className="w-full text-left p-2.5 rounded bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:border-violet-500/50 hover:text-white transition-all font-semibold"
                        >
                          {opt}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>

              {hasVoted && (
                <div className="text-center text-[10px] text-slate-500 font-medium">
                  ✓ Your vote has been recorded in the attendance logs.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Live classroom chat stream */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 flex flex-col h-[320px] justify-between">
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-white">Classroom Chatroom</h4>
            <span className="text-[10px] text-slate-500 font-mono">Real-time messaging with classmates</span>
          </div>

          {/* Messages overflow list */}
          <div className="flex-grow my-4 space-y-3 overflow-y-auto max-h-[160px] text-xs pr-1">
            {session.chats?.map((chat) => (
              <div key={chat.id} className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-slate-300">{chat.user}</span>
                  <span className="text-[8px] rounded bg-slate-950 px-1 py-0.2 text-slate-500 border border-slate-850 uppercase font-mono tracking-wide">{chat.role}</span>
                  <span className="text-[8px] text-slate-500 font-mono ml-auto">{chat.time}</span>
                </div>
                <p className="text-slate-400 leading-snug">{chat.message}</p>
              </div>
            ))}
          </div>

          {/* Message input */}
          <form onSubmit={handleSendChat} className="flex gap-1.5">
            <input
              type="text"
              placeholder="Ask a question..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              className="flex-grow rounded-lg bg-slate-950 px-3 py-2 text-xs text-white placeholder-slate-600 border border-slate-800 focus:outline-none focus:border-violet-500"
            />
            <button className="rounded-lg bg-violet-600 px-3.5 text-xs font-bold text-white hover:brightness-110 shrink-0">
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
}
