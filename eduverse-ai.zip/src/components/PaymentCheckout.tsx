import React, { useState } from "react";
import { CreditCard, Percent, ShieldCheck, Ticket, Sparkles, AlertCircle } from "lucide-react";
import { Course, FeatureFlags } from "../types";

interface PaymentCheckoutProps {
  course: Course;
  featureFlags: FeatureFlags;
  onCancel: () => void;
  onConfirmEnrollment: (paymentGateway?: string, couponCode?: string) => void;
}

export default function PaymentCheckout({
  course,
  featureFlags,
  onCancel,
  onConfirmEnrollment
}: PaymentCheckoutProps) {
  const [selectedGateway, setSelectedGateway] = useState<string>("bKash");
  const [couponCode, setCouponCode] = useState("");
  const [couponStatus, setCouponStatus] = useState<"none" | "valid" | "invalid">("none");
  const [discountAmount, setDiscountAmount] = useState(0);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!featureFlags.couponSystem) return;

    if (couponCode.toUpperCase() === "DISCOUNT50") {
      setCouponStatus("valid");
      setDiscountAmount(course.price * 0.5);
    } else {
      setCouponStatus("invalid");
      setDiscountAmount(0);
    }
  };

  const finalPrice = course.price - discountAmount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800/80 overflow-hidden shadow-2xl flex flex-col justify-between">
        
        {/* Checkout header */}
        <div className="p-6 pb-4 border-b border-slate-800/60">
          <span className="text-[10px] text-violet-400 font-mono uppercase tracking-wider block">Modular Enrollment Gateway</span>
          <h3 className="text-base font-extrabold text-white mt-1">Enrollment & Checkout</h3>
          <p className="text-xs text-slate-400 mt-1">Course: <span className="font-bold text-slate-200">{course.title}</span></p>
        </div>

        {/* Content body */}
        <div className="p-6 space-y-6 flex-grow overflow-y-auto max-h-[380px] text-xs">
          
          {/* STATE A: Checkout Feature Flag is Disabled (Free/Instant Mode) */}
          {!featureFlags.coursePurchase ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-violet-950/20 border border-violet-800/30 flex gap-3 items-start">
                <ShieldCheck className="h-5 w-5 text-violet-400 shrink-0" />
                <div className="space-y-1">
                  <span className="font-bold text-violet-300">Modular Gateway Simulation</span>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Course Purchase is currently **Disabled** by Admin feature flags. You can enroll instantly without processing real payment logs.
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center bg-slate-950 p-4 rounded-xl border border-slate-850">
                <span className="text-slate-400 font-bold">Standard Syllabus Price:</span>
                <span className="text-lg font-black text-white">{course.price > 0 ? `${course.price} BDT` : "Free"}</span>
              </div>
            </div>
          ) : (
            
            // STATE B: Checkout Feature Flag is Enabled (Real Checkout Simulation)
            <div className="space-y-5">
              
              {/* Payment gateway selection */}
              <div className="space-y-2">
                <label className="text-slate-300 font-bold block">Select Payment Gateway</label>
                
                <div className="grid grid-cols-2 gap-2 text-center text-xs font-bold">
                  {/* Bangladesh Gates */}
                  {[
                    { id: "bKash", label: "bKash (BD)", desc: "BKash mobile wallet" },
                    { id: "Nagad", label: "Nagad (BD)", desc: "Nagad post wallet" },
                    { id: "Stripe", label: "Stripe (Intl)", desc: "Global Credit Card" },
                    { id: "PayPal", label: "PayPal (Intl)", desc: "PayPal express checkout" }
                  ].map((gate) => (
                    <button
                      key={gate.id}
                      onClick={() => setSelectedGateway(gate.id)}
                      className={`p-3 rounded-xl border text-[11px] font-bold text-left transition-all ${
                        selectedGateway === gate.id
                          ? "bg-violet-950/30 border-violet-800 text-violet-300"
                          : "bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-300"
                      }`}
                    >
                      <span className="block">{gate.label}</span>
                      <span className="text-[8px] text-slate-500 font-normal block mt-0.5">{gate.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Coupon validator */}
              {featureFlags.couponSystem && (
                <div className="space-y-2">
                  <label className="text-slate-300 font-bold block flex items-center gap-1">
                    <Ticket className="h-3.5 w-3.5 text-violet-400" /> Apply Coupon Code
                  </label>
                  
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Try: DISCOUNT50"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="flex-grow rounded-lg bg-slate-950 px-3 py-2 text-white placeholder-slate-600 border border-slate-800 focus:outline-none"
                    />
                    <button type="submit" className="rounded-lg bg-slate-950 border border-slate-800 hover:border-slate-700 px-4 text-xs font-bold text-slate-300 hover:text-white">
                      Apply
                    </button>
                  </form>

                  {couponStatus === "valid" && (
                    <span className="text-[10px] text-emerald-400 font-medium block">✓ DISCOUNT50 code applied: 50% discount registered!</span>
                  )}
                  {couponStatus === "invalid" && (
                    <span className="text-[10px] text-red-400 font-medium block">✗ Invalid coupon code entered.</span>
                  )}
                </div>
              )}

              {/* Bill Details receipt */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-850 space-y-2 font-mono text-[10.5px]">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>{course.price} BDT</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Coupon Discount:</span>
                    <span>-{discountAmount} BDT</span>
                  </div>
                )}
                <div className="border-t border-slate-800 pt-2 flex justify-between font-bold text-white text-xs">
                  <span>Total Bill Amount:</span>
                  <span>{finalPrice} BDT</span>
                </div>
              </div>

            </div>
          )}

          {/* Guarantee stamp */}
          <div className="flex items-center gap-1.5 justify-center text-[10px] text-slate-500 font-medium">
            <ShieldCheck className="h-4 w-4 text-slate-500" />
            <span>Secure 256-bit SSL encrypted connection.</span>
          </div>

        </div>

        {/* Action controls */}
        <div className="p-6 border-t border-slate-800/60 flex items-center justify-end gap-3 bg-slate-900">
          <button
            onClick={onCancel}
            className="rounded-lg bg-slate-950 border border-slate-850 hover:border-slate-800 px-4 py-2 text-xs font-bold text-slate-400 hover:text-slate-300"
          >
            Cancel
          </button>
          
          <button
            onClick={() => onConfirmEnrollment(selectedGateway, couponCode)}
            className="rounded-lg bg-violet-600 hover:brightness-110 px-5 py-2 text-xs font-bold text-white shadow-lg shadow-violet-500/10"
          >
            {featureFlags.coursePurchase ? `Pay & Enroll Now` : `Enroll Instantly`}
          </button>
        </div>

      </div>
    </div>
  );
}
