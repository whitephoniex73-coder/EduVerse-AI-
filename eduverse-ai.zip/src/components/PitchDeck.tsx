import React, { useState, useEffect } from "react";
import { 
  ArrowRight, ArrowLeft, Play, Pause, Maximize2, Sparkles, Brain, 
  Target, GraduationCap, Award, Compass, Users, Layers, ShieldCheck, 
  Cpu, Globe, DollarSign, Rocket, Heart, Mail, MapPin, Phone, 
  CheckCircle2, Laptop, Calendar, ChevronRight, BarChart3, Info, HelpCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PitchDeckProps {
  onBackToHome?: () => void;
}

export default function PitchDeck({ onBackToHome }: PitchDeckProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPresenterNotes, setShowPresenterNotes] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [autoPlayDuration, setAutoPlayDuration] = useState(8); // seconds per slide
  const [progress, setProgress] = useState(0);

  // Presenter Notes for each slide to assist startups in pitch practice
  const presenterNotes = [
    "Cover Slide: Start with a powerful opening. EduVerse AI is not just another LMS; it is the cognitive infrastructure for South Asia's future leaders, starting with Bangladesh.",
    "Problem Statement: Contrast the high stress and financial burden of traditional coaching centers against the harsh reality of the skills gap. Highlight the $2B annual coaching shadow market.",
    "Solution: Introduce our AI-Copilot. Explain how standardizing curriculum-level intelligence in Bengali breaks barriers. EduVerse is adaptive, affordable, and 24/7.",
    "Market Opportunity: Our TAM is $10B+ in Bangladesh alone. Address the 40M student demographic. Highlight the exponential trajectory of the mobile-first internet economy.",
    "Product Demo: Demonstrate the interactive live metrics, the certified ledger lookup, and the real-time feedback loops. This is fully working technology, not slideware.",
    "Business Model: Explain our diversified monetization streams. Freemium core leads into low-friction premium bundles ($5/month average revenue per user). High volume, high margin.",
    "Competitive Advantage: We compete on accessibility and intelligence. While others host static PDF/videos, EduVerse generates personalized pathways, active feedback, and certified outcomes.",
    "Tech Stack: We built a lightweight semantic router on top of modern LLMs (including Gemini Flash) for lightning-fast sub-100ms response. Fully serverless, resilient, and optimized.",
    "Go To Market: We leverage regional university partnerships, campus ambassadors, and localized hyper-targeted academic content loops (SSC/HSC boards) to secure zero-cost organic acquisition.",
    "Growth Roadmap: We hit density in Dhaka and Chittagong in Year 1, scale across 64 districts in Year 2, and localized exports to MENA & South East Asia in Year 3.",
    "Financial Projection: Our projection is grounded in organic conversion rates. We expect profitability by Month 18, reaching $12M ARR by Year 3 with positive unit economics.",
    "Funding Requirement: We are raising a $1.5M Seed Round to accelerate model fine-tuning (40%), scale academic content channels (20%), and unlock rapid national distribution channels.",
    "Team Slide: A perfect blend of technical architects (ex-BUET developers) and regional domain experts. We have the perfect founder-market fit.",
    "Vision Slide: Our ultimate mission is the democratization of premium education. We believe high-tier cognitive guidance is a fundamental right, not a luxury.",
    "Closing Slide: Leave the slide with clear contact details. Open the floor for investor Q&A. Reinforce the key takeaway: Education's future is active, customized, and AI-led."
  ];

  // Auto Play Loop Timer
  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      setProgress(0);
      timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            handleNextSlide();
            return 0;
          }
          return prev + (100 / (autoPlayDuration * 10)); // increment based on ticks
        });
      }, 100);
    } else {
      setProgress(0);
    }
    return () => clearInterval(timer);
  }, [isPlaying, currentSlide]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "Space") {
        e.preventDefault();
        handleNextSlide();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        handlePrevSlide();
      } else if (e.key === "Escape" && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentSlide, isFullscreen]);

  const handleNextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setProgress(0);
  };

  const handlePrevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  };

  const toggleFullscreen = () => {
    const element = document.getElementById("pitch-deck-stage");
    if (!element) return;

    if (!isFullscreen) {
      if (element.requestFullscreen) {
        element.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  // -------------------------------------------------------------
  // SLIDES DATA DEFINITIONS WITH DATA-DRIVEN INTERACTIVE LAYOUTS
  // -------------------------------------------------------------

  const slides = [
    // SLIDE 1: COVER
    {
      id: "cover",
      category: "INTRODUCTION",
      title: "EduVerse AI",
      subtitle: "The Future of Learning Starts Here.",
      content: (
        <div className="flex flex-col items-center justify-center text-center space-y-8 h-full">
          {/* Main Logo Graphic */}
          <div className="relative">
            <div className="absolute inset-0 bg-violet-500/20 blur-[60px] rounded-full scale-125"></div>
            <div className="relative h-20 w-20 rounded-3xl bg-gradient-to-tr from-violet-600 to-indigo-500 flex items-center justify-center shadow-2xl shadow-violet-500/30">
              <Sparkles className="h-10 w-10 text-white animate-pulse" />
            </div>
          </div>

          <div className="space-y-4">
            <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white uppercase">
              EduVerse <span className="text-violet-500">AI</span>
            </h1>
            <p className="text-md sm:text-lg text-slate-400 font-medium max-w-xl mx-auto leading-relaxed">
              Cognitive AI Infrastructure Democratizing Premium Interactive Education across South Asia.
            </p>
          </div>

          {/* Metadata badges */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <span className="px-3.5 py-1.5 rounded-full bg-slate-900 border border-white/5 text-xs text-slate-400 font-mono">
              🚀 Seed Stage Pitch Deck
            </span>
            <span className="px-3.5 py-1.5 rounded-full bg-violet-950/40 border border-violet-500/10 text-xs text-violet-300 font-mono">
              🇧🇩 Bangladesh Focused, Global Target
            </span>
          </div>

          {/* Founders Info Grid */}
          <div className="grid grid-cols-3 gap-6 pt-10 border-t border-white/5 max-w-2xl w-full text-left">
            <div>
              <div className="text-xs font-bold text-white">Tanzim Ahmed</div>
              <div className="text-[10px] text-slate-500 font-mono">Founder & CEO (ex-BUET)</div>
            </div>
            <div>
              <div className="text-xs font-bold text-white">Sabrina Jahan</div>
              <div className="text-[10px] text-slate-500 font-mono">Chief Academic Officer</div>
            </div>
            <div>
              <div className="text-xs font-bold text-white">Zahidul Islam</div>
              <div className="text-[10px] text-slate-500 font-mono">Chief Tech Architect</div>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 2: PROBLEM STATEMENT
    {
      id: "problem",
      category: "THE PROBLEM",
      title: "The Crisis in South Asian Supplementary Education",
      subtitle: "Inequitable, Expensive, and Outdated Learning Mechanisms.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          <div className="space-y-6">
            <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/20 space-y-2">
              <div className="flex items-center gap-2 text-red-400 text-xs font-bold font-mono">
                <span className="h-2 w-2 rounded-full bg-red-500"></span> ACCESS DISPARITY
              </div>
              <h4 className="text-sm font-bold text-white">Geographic Quality Concentration</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Elite board mentors and university prep tutors are concentrated in metropolitan capitals (Dhaka/Chittagong). Rural students lack premium guide channels completely.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/20 space-y-2">
              <div className="flex items-center gap-2 text-red-400 text-xs font-bold font-mono">
                <span className="h-2 w-2 rounded-full bg-red-500"></span> SHADOW EDUCATION COST
              </div>
              <h4 className="text-sm font-bold text-white">Exorbitant Private Coaching Fees</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Middle-class families spend up to 40% of their disposable household income on private high school coaching and test preparations, driving high social friction.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/20 space-y-2">
              <div className="flex items-center gap-2 text-red-400 text-xs font-bold font-mono">
                <span className="h-2 w-2 rounded-full bg-red-500"></span> THE SKILLS GAP
              </div>
              <h4 className="text-sm font-bold text-white">Rote-Memorization vs. Industry Fit</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                National exams reward standard dry memorization. 83% of college graduates fail standard technical hiring benchmarks for modern freelance or software roles.
              </p>
            </div>
          </div>

          {/* Graphic Side */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-6 flex flex-col justify-between">
            <div>
              <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">Pain Points Quantification</span>
              <h3 className="text-lg font-bold text-white mt-1">The High Price of Rote Systems</h3>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">Average Student Monthly Coaching Cost</span>
                  <span className="text-red-400 font-mono">৳5,000 - ৳12,000</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-red-500" style={{ width: "85%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">Access to Personalized High-Tier Instructors</span>
                  <span className="text-red-400 font-mono">Less than 8%</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-red-500" style={{ width: "8%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">Unemployment / Skills Gap on Graduation</span>
                  <span className="text-red-400 font-mono">Over 47%</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-red-500" style={{ width: "47%" }}></div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 text-[11px] text-slate-500 italic">
              "Supplementary offline coaching is a highly fragmented, highly stressful, and low-efficiency loop that is desperately ripe for digital disintermediation."
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 3: THE SOLUTION
    {
      id: "solution",
      category: "THE SOLUTION",
      title: "EduVerse AI: Cognitive Education Core",
      subtitle: "Unlocking custom-tailored active guidance for every learner.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full items-stretch">
          <div className="p-6 rounded-2xl bg-gradient-to-b from-violet-950/20 to-slate-900/60 border border-violet-500/15 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-violet-900/20 border border-violet-500/30 text-violet-400 w-fit">
                <Brain className="h-6 w-6" />
              </div>
              <h3 className="text-md font-bold text-white">Adaptive AI Copilot</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                24/7 hyper-personalized chat companion fine-tuned to local board books (NCTB Grade 9-12) and civil service examinations. Resolves study flaws with custom code scripts and instant explanations in native Bengali.
              </p>
            </div>
            <div className="text-[10px] font-mono text-violet-400 uppercase tracking-wider pt-4 border-t border-white/5">
              🚀 100ms average latency response
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-indigo-950/20 to-slate-900/60 border border-indigo-500/15 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-indigo-900/20 border border-indigo-500/30 text-indigo-400 w-fit">
                <Layers className="h-6 w-6" />
              </div>
              <h3 className="text-md font-bold text-white">Full-Stack Live Ecosystem</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Synchronous live broadcast networks equipped with real-time class diagnostics, immediate chat translations, active responsive polls, and parent portal check-ins. No HMR lag, fully responsive stream fallbacks.
              </p>
            </div>
            <div className="text-[10px] font-mono text-indigo-400 uppercase tracking-wider pt-4 border-t border-white/5">
              📺 Adaptive 1080p Stream Core
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-emerald-950/20 to-slate-900/60 border border-emerald-500/15 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-emerald-900/20 border border-emerald-500/30 text-emerald-400 w-fit">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="text-md font-bold text-white">Public Certificate Ledger</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Cryptographically certified badges mapping completed board preparations and high-income skills. Features a verified public API endpoint allowing recruitment firms to validate applicant credentials instantly.
              </p>
            </div>
            <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider pt-4 border-t border-white/5">
              🛡️ Validated Secure Hash
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 4: MARKET OPPORTUNITY
    {
      id: "market",
      category: "MARKET OPPORTUNITY",
      title: "Bangladesh Supplementary Education Market Size",
      subtitle: "A massive, hyper-engaged, digital-first consumer cohort.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          {/* Custom Market Size Metric Visualizer */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-6">
            <div>
              <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">Addressable Demographics</span>
              <h3 className="text-lg font-bold text-white mt-1">Multi-Tier TAM Breakdown</h3>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-[10px] text-slate-500 font-mono">TAM (TOTAL ADDRESSABLE MARKET)</div>
                  <div className="text-md font-black text-white">Bangladesh + Regional South Asia</div>
                </div>
                <div className="text-xl font-bold text-violet-400 font-mono">$12.5 Billion</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-[10px] text-slate-500 font-mono">SAM (SERVICEABLE ADDRESSABLE MARKET)</div>
                  <div className="text-md font-black text-white">40M+ K-12 and College Students</div>
                </div>
                <div className="text-xl font-bold text-indigo-400 font-mono">$2.1 Billion</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-[10px] text-slate-500 font-mono">SOM (SERVICEABLE OBTAINABLE MARKET)</div>
                  <div className="text-md font-black text-white">Tech-adapted, active internet users</div>
                </div>
                <div className="text-xl font-bold text-emerald-400 font-mono">$450 Million</div>
              </div>
            </div>
          </div>

          {/* Market Drivers Trend List */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">Key Tailwinds Driving Our Growth</h3>

            <div className="space-y-3.5">
              <div className="flex gap-3">
                <span className="h-5 w-5 rounded-full bg-violet-950 border border-violet-800 text-[10px] font-bold text-violet-400 flex items-center justify-center shrink-0 mt-0.5">✓</span>
                <p className="text-xs text-slate-400 leading-normal">
                  <strong className="text-slate-200">Mobile Internet Penetration:</strong> Over 120 Million mobile internet subscribers in Bangladesh; low-cost high-speed 4G expansion has flattened access barriers.
                </p>
              </div>

              <div className="flex gap-3">
                <span className="h-5 w-5 rounded-full bg-violet-950 border border-violet-800 text-[10px] font-bold text-violet-400 flex items-center justify-center shrink-0 mt-0.5">✓</span>
                <p className="text-xs text-slate-400 leading-normal">
                  <strong className="text-slate-200">The Rise of Remote Income:</strong> Bangladesh ranks as the #2 global supplier of online freelancing. Youth demand targeted tech certifications mapped to international platforms.
                </p>
              </div>

              <div className="flex gap-3">
                <span className="h-5 w-5 rounded-full bg-violet-950 border border-violet-800 text-[10px] font-bold text-violet-400 flex items-center justify-center shrink-0 mt-0.5">✓</span>
                <p className="text-xs text-slate-400 leading-normal">
                  <strong className="text-slate-200">Parental Commitment to Prep:</strong> Cultural mandate prioritize student performance above all other household expenses, securing incredibly high customer lifetime value (LTV).
                </p>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 5: PRODUCT DEMONSTRATION (INTERACTIVE MINIATURE ENGINE!)
    {
      id: "product",
      category: "PRODUCT SHOWCASE",
      title: "Experience EduVerse AI Firsthand",
      subtitle: "Operational cognitive systems available instantly.",
      content: (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full items-stretch">
          {/* Mock Dashboard Widget Panel */}
          <div className="lg:col-span-4 rounded-2xl bg-slate-900/60 p-5 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-[10px] text-slate-500 font-mono uppercase">VIRTUAL STUDENT VIEW</span>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-violet-600/20 border border-violet-500/20 flex items-center justify-center text-violet-400 text-xs font-bold">TA</div>
                <div>
                  <h4 className="text-xs font-bold text-white">Tanjim Ahmed</h4>
                  <p className="text-[10px] text-slate-400">Class 12 - Science Track</p>
                </div>
              </div>
              
              <div className="space-y-2 pt-3">
                <div className="p-3 rounded-lg bg-slate-950 border border-white/5 flex justify-between items-center text-xs">
                  <span className="text-slate-400">Board Math Prep</span>
                  <span className="text-violet-400 font-bold font-mono">92% Done</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-white/5 flex justify-between items-center text-xs">
                  <span className="text-slate-400">AI Tutor Queries</span>
                  <span className="text-emerald-400 font-bold font-mono">148 Solved</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-white/5 flex justify-between items-center text-xs">
                  <span className="text-slate-400">Verified Certificate Key</span>
                  <span className="text-amber-400 font-mono text-[9px] truncate max-w-[100px]">EV-CERT-7402</span>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-violet-950/20 border border-violet-800/40 text-[10px] text-violet-300 leading-normal">
              ℹ️ Try navigating the platform's core views using the top navigation header bar anytime!
            </div>
          </div>

          {/* Mini Interactive AI Tutor Sandbox */}
          <div className="lg:col-span-8 rounded-2xl bg-slate-950 p-5 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-3 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4 text-violet-400" />
                  <span className="text-xs font-bold text-white">Live AI Cognitive Sandbox</span>
                </div>
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              </div>

              <div className="space-y-2 max-h-[220px] overflow-y-auto">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-white/5 text-[11px] text-slate-300">
                  <span className="font-bold text-violet-400">Tanjim:</span> "What are the common physics mechanics formulas for HSC board?"
                </div>
                <div className="p-3 rounded-xl bg-violet-950/20 border border-violet-500/20 text-[11px] text-slate-200 space-y-1.5">
                  <div className="font-mono text-[9px] text-violet-400 font-bold uppercase">🤖 EduVerse AI CO-PILOT:</div>
                  <p>Here are the key formulas calibrated to the NCTB curriculum:</p>
                  <ul className="list-disc pl-4 space-y-1 text-slate-400 font-mono text-[10px]">
                    <li>Linear Momentum: p = mv</li>
                    <li>Centripetal Acceleration: a = v² / r</li>
                    <li>Kinetic Energy: Ek = 1/2 m v²</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-3 border-t border-white/5">
              <input
                type="text"
                disabled
                placeholder="Try our full interactive AI Labs on the top nav menu tab!"
                className="flex-grow rounded-lg bg-slate-900 border border-white/5 px-3 py-1.5 text-xs text-slate-500 placeholder-slate-600 focus:outline-none"
              />
              <button disabled className="px-4 py-1.5 rounded-lg bg-violet-600 opacity-50 text-xs font-bold text-white">
                Send
              </button>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 6: BUSINESS MODEL
    {
      id: "business",
      category: "BUSINESS MODEL",
      title: "Diversified, High-Volume Monetization Engine",
      subtitle: "Achieving low client acquisition cost with massive customer lifetime value.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-full items-stretch">
          {[
            {
              title: "Board Prep Bundles",
              pricing: "৳999 - ৳1,999 One-time",
              desc: "Subject-focused exam-prep bundles mapping HSC / SSC boards, mock examination diagnostics, and active tutor access.",
              color: "border-violet-500/20",
              badge: "Core Volume"
            },
            {
              title: "EduVerse Premium Pass",
              pricing: "৳499 / Month Subscription",
              desc: "Continuous, recurring access to premium Live classrooms, advanced skills tracks, complete database of tests, and parent guides.",
              color: "border-indigo-500/20",
              badge: "Highly Recurring"
            },
            {
              title: "Enterprise Skill Tracks",
              pricing: "B2B Tier Licensing",
              desc: "Partnering with national tech hubs and corporate entities to offer high-caliber certified tracks in engineering, design, and math.",
              color: "border-emerald-500/20",
              badge: "High-Margin"
            },
            {
              title: "Career Matchmaking",
              pricing: "15% Placement Royalty",
              desc: "Securing commission from international remote clients and domestic firms for direct onboarding from our top-certified talent pool.",
              color: "border-amber-500/20",
              badge: "Upside Potential"
            }
          ].map((model, i) => (
            <div key={i} className={`p-5 rounded-2xl bg-slate-900/60 border ${model.color} flex flex-col justify-between`}>
              <div className="space-y-3">
                <span className="px-2 py-0.5 rounded-full bg-slate-950 border border-white/5 text-[9px] font-mono text-slate-400 font-bold uppercase">{model.badge}</span>
                <h3 className="text-sm font-bold text-white mt-1">{model.title}</h3>
                <div className="text-xs font-black text-violet-400 font-mono">{model.pricing}</div>
                <p className="text-[11px] text-slate-400 leading-relaxed">{model.desc}</p>
              </div>
              <div className="pt-4 border-t border-white/5 text-[9px] text-slate-500 font-mono">
                🎯 LTV to CAC Ratio Target: 7.2x
              </div>
            </div>
          ))}
        </div>
      )
    },

    // SLIDE 7: COMPETITIVE ADVANTAGE
    {
      id: "competition",
      category: "COMPETITION",
      title: "Unmatched Defensive Moat Structure",
      subtitle: "Why traditional systems and generic static LMS engines fall flat.",
      content: (
        <div className="space-y-6 h-full flex flex-col justify-between">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 uppercase tracking-wider font-mono text-[10px]">
                  <th className="py-3 px-4">Feature Set</th>
                  <th className="py-3 px-4 text-violet-400">EduVerse AI</th>
                  <th className="py-3 px-4">Traditional Coaching</th>
                  <th className="py-3 px-4">Static LMS Channels</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Interactive AI Tutor Response</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">✓ Native sub-100ms Bengali core</td>
                  <td className="py-3.5 px-4">✗ Offline class hours only</td>
                  <td className="py-3.5 px-4">✗ Basic search bar query</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Personalized Diagnostics</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">✓ Adaptive weak-area logs</td>
                  <td className="py-3.5 px-4">✗ Static printouts</td>
                  <td className="py-3.5 px-4">✗ Generic score metric</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Tuition Affordability</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">✓ ~৳499/mo (Highly accessible)</td>
                  <td className="py-3.5 px-4">✗ ৳5,000 - ৳12,000/mo</td>
                  <td className="py-3.5 px-4">✓ Low cost, low engagement</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Outcome Credential</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">✓ Ledger-verified API access</td>
                  <td className="py-3.5 px-4">✗ None</td>
                  <td className="py-3.5 px-4">✗ Static unverified PDFs</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-white/5">
            <div className="p-4 rounded-xl bg-violet-950/20 border border-violet-500/10 space-y-1">
              <h4 className="text-xs font-bold text-violet-300">Defensive Data Moat</h4>
              <p className="text-[11px] text-slate-400">Our models are optimized on millions of historical NCTB, admission, and board questions, producing highly tailored response accuracy that generic LLMs cannot replicate.</p>
            </div>
            <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/10 space-y-1">
              <h4 className="text-xs font-bold text-indigo-300">The Network Loop Effect</h4>
              <p className="text-[11px] text-slate-400">Integrating students, parents, expert guides, and potential employers in a singular ledger ecosystem secures an incredibly high switching cost defense barrier.</p>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 8: TECH STACK
    {
      id: "technology",
      category: "TECHNOLOGY STACK",
      title: "State-of-the-Art Scalable Architecture",
      subtitle: "Engineered for high availability, security, and sub-100ms response cycles.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 h-full items-stretch">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2.5 rounded-xl bg-violet-900/20 border border-violet-500/30 text-violet-400 w-fit">
                <Cpu className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">AI Core Router</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Lightweight semantic matching layer hosted on serverless infrastructure. Intercepts study inputs and maps to customized LLM endpoints (including Gemini Flash) for hyper-fast explanation outputs.
              </p>
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase">Gemini Flash integration</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2.5 rounded-xl bg-indigo-900/20 border border-indigo-500/30 text-indigo-400 w-fit">
                <Layers className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Express / React Core</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Modern full-stack setup with esbuild. Resolves static bundles flawlessly into a unified container image with optimized cold-start times, fully immune to standard HMR connection breaks.
              </p>
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase">Modular esbuild compilation</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2.5 rounded-xl bg-emerald-900/20 border border-emerald-500/30 text-emerald-400 w-fit">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Ledger Verification Portal</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Encrypted hash-matching portal enabling instantaneous verified key lookup under 100 milliseconds. Highly secure and completely eliminates manual academic transcript fraud issues.
              </p>
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase">SHA-256 crypt security</span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="p-2.5 rounded-xl bg-amber-900/20 border border-amber-500/30 text-amber-400 w-fit">
                <Globe className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Adaptive Live Streaming</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Integrated real-time streaming fallbacks with minimal buffer lag. Designed for unstable cellular mobile connections common across remote regional districts in Bangladesh.
              </p>
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase">WebRTC + adaptive HLS formats</span>
          </div>
        </div>
      )
    },

    // SLIDE 9: GO TO MARKET (GTM)
    {
      id: "gtm",
      category: "GO TO MARKET",
      title: "GTM: Integrated Student Loops",
      subtitle: "Securing high-velocity organic reach through existing networks.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="h-10 w-10 rounded-xl bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center shrink-0 font-bold">1</div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Hyper-Targeted Academic Loops</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Focus on peak exam periods (SSC and HSC). Deliver free board practice tests, automated paper grading, and diagnostic summaries to fuel viral user acquisition.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="h-10 w-10 rounded-xl bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center shrink-0 font-bold">2</div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Campus Ambassador Networks</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Deploy over 500 active college students inside high schools and universities to drive peer-to-peer signups, community forum group posts, and regional test leagues.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="h-10 w-10 rounded-xl bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center shrink-0 font-bold">3</div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">Skills to Income Matchmaking</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Bridge the freelancing track directly to global software and marketing gig opportunities, generating strong word-of-mouth success loops among graduates.
                </p>
              </div>
            </div>
          </div>

          {/* GTM Loop Visual Grid */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-4">
            <div className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">Growth Loop Mechanics</div>
            <h3 className="text-base font-bold text-white">Zero-Cost Organic Acquisition Flywheel</h3>

            <div className="space-y-2.5 pt-2">
              <div className="p-3 bg-slate-950 rounded-xl border border-white/5 flex justify-between items-center text-xs">
                <span className="text-slate-400">1. Share Board Prep Challenge</span>
                <span className="text-violet-400 font-mono">↗ Student Invites Peer</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-white/5 flex justify-between items-center text-xs">
                <span className="text-slate-400">2. Free Diagnostic Review</span>
                <span className="text-indigo-400 font-mono">↗ AI Detects Flaws</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-white/5 flex justify-between items-center text-xs">
                <span className="text-slate-400">3. Parents Dashboard Log</span>
                <span className="text-emerald-400 font-mono">↗ Parent Converts Premium</span>
              </div>
            </div>

            <div className="p-3 bg-violet-950/20 border border-violet-800/40 rounded-xl text-[10px] text-violet-300 leading-normal">
              🔥 In pilot testing, we achieved a viral coefficient (K-factor) of 1.45, with 60% of new signups originating directly from student invitations.
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 10: GROWTH ROADMAP
    {
      id: "roadmap",
      category: "GROWTH ROADMAP",
      title: "Three-Year Strategic Progression",
      subtitle: "From regional density to global decentralized scale.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full items-stretch">
          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="px-3 py-1 rounded-full bg-violet-950/60 border border-violet-800/50 text-[10px] font-mono text-violet-300 font-bold uppercase">Year 1</span>
                <span className="text-xs text-slate-500 font-mono">H2 2026</span>
              </div>
              <h3 className="text-md font-bold text-white">Bangladesh Launch & Density</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Deploy NCTB Grade 9-12 core board preparational tracks, fine-tune the high-performance Bengali AI tutor, and secure campus ambassadorship networks across top Dhaka colleges.
              </p>
            </div>
            <div className="space-y-1.5 pt-4 border-t border-white/5 text-[10px] font-mono text-slate-500">
              <div>🎯 Target: 200K Active Users</div>
              <div>⚡ Revenue: $350K ARR</div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-800/50 text-[10px] font-mono text-indigo-300 font-bold uppercase">Year 2</span>
                <span className="text-xs text-slate-500 font-mono">H1 2027</span>
              </div>
              <h3 className="text-md font-bold text-white">National Multi-Role Scale</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Incorporate BCS Civil Service testing modules, scale specialized software and remote freelancing guide paths, roll out parent dashboard subscription matrices across all 64 districts.
              </p>
            </div>
            <div className="space-y-1.5 pt-4 border-t border-white/5 text-[10px] font-mono text-indigo-400 font-bold">
              <div>🎯 Target: 1.2M Active Users</div>
              <div>⚡ Revenue: $2.4M ARR</div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-800/50 text-[10px] font-mono text-emerald-300 font-bold uppercase">Year 3</span>
                <span className="text-xs text-slate-500 font-mono">2028+</span>
              </div>
              <h3 className="text-md font-bold text-white">Global Regional Export</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Localize core cognitive AI routers to matching high-friction emerging markets across MENA and South Asia. Secure certified recruiter pipelines straight to global gig outlets.
              </p>
            </div>
            <div className="space-y-1.5 pt-4 border-t border-white/5 text-[10px] font-mono text-emerald-400 font-bold">
              <div>🎯 Target: 5.0M Active Users</div>
              <div>⚡ Revenue: $12.0M ARR</div>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 11: FINANCIAL PROJECTION (CUSTOM RENDERED GLOWING SVG CHART!)
    {
      id: "financial",
      category: "FINANCIAL FORECAST",
      title: "Strong Scalable Unit Economics",
      subtitle: "Securing robust compound growth with excellent net operating margins.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          {/* Custom Glowing SVG Multi-Year Growth Chart */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-4 relative overflow-hidden">
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-slate-500 font-mono uppercase">Revenue & User Trajectory</span>
              <span className="text-xs text-emerald-400 font-mono font-bold">+160% CAGR</span>
            </div>

            {/* SVG Plot */}
            <div className="h-44 w-full relative">
              <svg viewBox="0 0 400 160" className="w-full h-full">
                <defs>
                  <linearGradient id="chartGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                
                {/* Grid Lines */}
                <line x1="10" y1="20" x2="390" y2="20" stroke="#1e293b" strokeDasharray="3,3" />
                <line x1="10" y1="70" x2="390" y2="70" stroke="#1e293b" strokeDasharray="3,3" />
                <line x1="10" y1="120" x2="390" y2="120" stroke="#1e293b" strokeDasharray="3,3" />

                {/* Shaded Area under path */}
                <path d="M 20 135 L 140 105 L 260 55 L 380 15 L 380 140 L 20 140 Z" fill="url(#chartGlow)" />
                
                {/* Trend line */}
                <path d="M 20 135 L 140 105 L 260 55 L 380 15" fill="none" stroke="#8b5cf6" strokeWidth="3" strokeLinecap="round" />
                
                {/* Interactive Dot checkpoints */}
                <circle cx="20" cy="135" r="5" fill="#a78bfa" />
                <circle cx="140" cy="105" r="5" fill="#a78bfa" />
                <circle cx="260" cy="55" r="5" fill="#a78bfa" />
                <circle cx="380" cy="15" r="5" fill="#a78bfa" />

                {/* Text Labels inside SVG */}
                <text x="20" y="155" fill="#64748b" fontSize="10" fontFamily="monospace">Pilot</text>
                <text x="140" y="155" fill="#64748b" fontSize="10" fontFamily="monospace">Year 1</text>
                <text x="260" y="155" fill="#64748b" fontSize="10" fontFamily="monospace">Year 2</text>
                <text x="360" y="155" fill="#64748b" fontSize="10" fontFamily="monospace">Year 3</text>

                <text x="35" y="130" fill="#a78bfa" fontSize="9" fontFamily="monospace">15k Users</text>
                <text x="145" y="98" fill="#a78bfa" fontSize="9" fontFamily="monospace">200k Users</text>
                <text x="265" y="48" fill="#a78bfa" fontSize="9" fontFamily="monospace">1.2M Users</text>
                <text x="305" y="15" fill="#a78bfa" fontSize="9" fontFamily="monospace">5.0M Users</text>
              </svg>
            </div>

            <div className="text-[10px] text-slate-500 font-mono text-center">
              Figure: Cumulative verified student cohort exponential adoption curves.
            </div>
          </div>

          {/* Forecast Grid metrics */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">Robust Projected Margins</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Because AI automation resolves tutoring constraints, our marginal server cost drops exponentially as student volume scales, securing over <strong className="text-white">74% Gross Margins</strong>.
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-white/5 space-y-1">
                <div className="text-[9px] text-slate-500 font-mono uppercase">Year 1 ARR</div>
                <div className="text-lg font-extrabold text-white">$350,000</div>
                <div className="text-[9px] text-emerald-400 font-mono">18% Gross Margin</div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-white/5 space-y-1">
                <div className="text-[9px] text-slate-500 font-mono uppercase">Year 2 ARR</div>
                <div className="text-lg font-extrabold text-white">$2,400,000</div>
                <div className="text-[9px] text-emerald-400 font-mono">48% Gross Margin</div>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-white/5 space-y-1 col-span-2">
                <div className="text-[9px] text-slate-500 font-mono uppercase">Year 3 ARR</div>
                <div className="text-lg font-extrabold text-white">$12,000,000</div>
                <div className="text-[9px] text-emerald-400 font-mono">74% Projected Gross Margin & Profitability</div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 12: FUNDING REQUIREMENT
    {
      id: "funding",
      category: "FUNDING REQUIREMENT",
      title: "Raising $1.5M Seed Investment",
      subtitle: "Primed to accelerate technical models, scale courses, and capture national density.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-violet-500/10 space-y-2">
              <div className="text-xs text-violet-400 font-bold uppercase tracking-wider font-mono">Investment Request</div>
              <h3 className="text-3xl font-black text-white font-mono">$1,500,000</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Structured Seed Round equity funding target. Calibrated to unlock Month-24 expansion milestones, securing ARR profitability structures comfortably.
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Growth Target Metrics:</h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-white/5 font-mono">
                  <span className="text-slate-500 text-[10px] block">TARGET USER SCALE</span>
                  <span className="text-white font-bold">1.5M Active</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-white/5 font-mono">
                  <span className="text-slate-500 text-[10px] block">MONTHLY BURN RATE</span>
                  <span className="text-white font-bold">$45,000 Avg</span>
                </div>
              </div>
            </div>
          </div>

          {/* Budget Allocation Progress representation */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-5">
            <div>
              <span className="text-[10px] text-slate-500 font-mono uppercase">Use of Proceeds Allocation</span>
              <h3 className="text-lg font-bold text-white mt-1">Resource Distribution Model</h3>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">40% - AI Models Fine-tuning & R&D</span>
                  <span className="text-violet-400 font-mono">$600K</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-violet-500" style={{ width: "40%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">30% - Marketing & Campus Expansion</span>
                  <span className="text-indigo-400 font-mono">$450K</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-indigo-500" style={{ width: "30%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">20% - High-Tier Course Production</span>
                  <span className="text-emerald-400 font-mono">$300K</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-emerald-500" style={{ width: "20%" }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-400">10% - DevOps & Security Ledger Infrastructure</span>
                  <span className="text-amber-400 font-mono">$150K</span>
                </div>
                <div className="h-2 rounded-full bg-slate-850 overflow-hidden">
                  <div className="h-full bg-amber-500" style={{ width: "10%" }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 13: THE TEAM
    {
      id: "team",
      category: "LEADERSHIP TEAM",
      title: "Passionate Developers & Domain Experts",
      subtitle: "Unlocking powerful execution based on genuine founder-market alignment.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full items-stretch">
          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="h-16 w-16 rounded-full bg-violet-600/20 border border-violet-500/30 flex items-center justify-center font-black text-xl text-violet-400">
                TA
              </div>
              <div>
                <h3 className="text-md font-bold text-white">Tanjim Ahmed</h3>
                <p className="text-[10px] text-violet-400 font-mono font-bold uppercase tracking-wider">FOUNDER & CEO</p>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Ex-BUET CSE software engineer. Architected modular web models and managed regional testing applications serving over 50k monthly active users.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 pt-4 border-t border-white/5 font-mono">
              📧 tanjim@eduverse.ai
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="h-16 w-16 rounded-full bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center font-black text-xl text-indigo-400">
                SJ
              </div>
              <div>
                <h3 className="text-md font-bold text-white">Sabrina Jahan</h3>
                <p className="text-[10px] text-indigo-400 font-mono font-bold uppercase tracking-wider">CHIEF ACADEMIC OFFICER</p>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Lead curriculum designer. ex-HSC Board consultant with over 8 years of specialized instructional design and textbook taxonomy training.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 pt-4 border-t border-white/5 font-mono">
              📧 sabrina@eduverse.ai
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900/80 to-slate-950 border border-white/5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="h-16 w-16 rounded-full bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center font-black text-xl text-emerald-400">
                ZI
              </div>
              <div>
                <h3 className="text-md font-bold text-white">Zahidul Islam</h3>
                <p className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider">CHIEF TECHNOLOGY ARCHITECT</p>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Full-stack systems architect specializing in highly concurrent streaming systems and cryptographically verified transaction ledger structures.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 pt-4 border-t border-white/5 font-mono">
              📧 zahid@eduverse.ai
            </div>
          </div>
        </div>
      )
    },

    // SLIDE 14: THE VISION
    {
      id: "vision",
      category: "COMPANY VISION",
      title: "Cognitive Empowerment at Infinite Scale",
      subtitle: "Why we do what we do.",
      content: (
        <div className="flex flex-col items-center justify-center text-center space-y-6 max-w-3xl mx-auto h-full">
          <div className="p-3 rounded-full bg-violet-600/20 border border-violet-500/20 text-violet-400 animate-pulse">
            <Heart className="h-8 w-8" />
          </div>
          
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-normal">
            "We believe premium educational guidance is not a luxury reserved for the elite — it is a basic human right."
          </h2>

          <div className="h-0.5 w-16 bg-gradient-to-r from-violet-500 to-indigo-500 my-2"></div>

          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl">
            By embedding regional curriculum intelligence in highly optimized, low-cost serverless models, we shatter geographic and financial barriers. Any child in the most remote district of Bangladesh can now learn side-by-side with an elite personal mentor, leveling the playing field forever.
          </p>

          <div className="flex items-center gap-6 text-[11px] text-slate-500 font-mono uppercase tracking-widest pt-6">
            <span>🛡️ Decentered</span>
            <span>⚡ Instantaneous</span>
            <span>🤝 Equalizing</span>
          </div>
        </div>
      )
    },

    // SLIDE 15: CLOSING & CALL TO ACTION
    {
      id: "closing",
      category: "OUTRO",
      title: "Building the Future of Education",
      subtitle: "Join us in reshaping cognitive educational access globally.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center h-full">
          <div className="space-y-6">
            <h1 className="text-3xl sm:text-5xl font-black text-white leading-tight">
              Let's build the <br />
              <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-white bg-clip-text text-transparent">
                Future together.
              </span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              We are actively scheduling introductory alignment dialogues with accelerators, venture funds, and angel syndicates who share our obsessive vision for automated, localized cognitive education.
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div className="flex items-center gap-3 text-slate-300">
                <MapPin className="h-4 w-4 text-violet-400 shrink-0" />
                <span>Gulshan-2, Dhaka, Bangladesh</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <Mail className="h-4 w-4 text-violet-400 shrink-0" />
                <span>investors@eduverse.ai</span>
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <Phone className="h-4 w-4 text-violet-400 shrink-0" />
                <span>+880 1712-345678</span>
              </div>
            </div>
          </div>

          {/* Contact sandbox card / Quick Message simulator */}
          <div className="rounded-2xl bg-slate-900/60 p-6 border border-white/5 space-y-4">
            <h3 className="text-sm font-bold text-white">Ready to connect with founders?</h3>
            <p className="text-[11px] text-slate-400">Leave your credentials. Our investor relations deck and automated schedule calendars will be instantly dispatched.</p>
            
            <form onSubmit={(e) => { e.preventDefault(); alert("Investor interest received. Our relationship packet has been auto-dispatched!"); }} className="space-y-3 pt-2">
              <input
                type="text"
                required
                placeholder="Full Name / Venture Fund"
                className="w-full rounded-xl bg-slate-950 border border-white/5 px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
              />
              <input
                type="email"
                required
                placeholder="Partner Professional Email"
                className="w-full rounded-xl bg-slate-950 border border-white/5 px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
              />
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-bold text-white transition-all"
              >
                Request Private Term Sheet
              </button>
            </form>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8">
      {/* Upper Navigation Row with controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Rocket className="h-5 w-5 text-violet-400" />
            <h2 className="text-xl font-bold text-white">Venture Capital Pitch Deck</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">Presenting EduVerse AI: Seed Valuation, Bangladesh EdTech TAM, and Interactive Prototype demo.</p>
        </div>

        {/* Presenter controls */}
        <div className="flex flex-wrap items-center gap-2">
          {onBackToHome && (
            <button
              onClick={onBackToHome}
              className="px-3.5 py-1.5 rounded-lg bg-slate-900 border border-white/5 hover:border-white/10 text-xs font-bold text-slate-300 hover:text-white transition-all"
            >
              Back to Catalog
            </button>
          )}

          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
              isPlaying 
                ? "bg-amber-600 text-white" 
                : "bg-violet-600 text-white hover:brightness-110"
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="h-3.5 w-3.5" /> Pause AutoPlay ({autoPlayDuration}s)
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5" /> Start AutoPlay
              </>
            )}
          </button>

          <button
            onClick={() => setShowPresenterNotes(!showPresenterNotes)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
              showPresenterNotes 
                ? "bg-slate-800 text-white border-white/10" 
                : "bg-slate-950 text-slate-400 border-white/5 hover:text-white"
            }`}
          >
            Presenter Notes
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg bg-slate-950 border border-white/5 hover:border-white/10 text-slate-400 hover:text-white"
            title="Toggle presentation stage fullscreen"
          >
            <Maximize2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Slide Stage Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Dynamic list of Slides */}
        <div className="lg:col-span-3 rounded-2xl bg-slate-900/40 p-4 border border-white/5 space-y-2 max-h-[550px] overflow-y-auto">
          <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest block mb-2 px-2">Table of Contents</span>
          {slides.map((slide, idx) => (
            <button
              key={slide.id}
              onClick={() => {
                setCurrentSlide(idx);
                setProgress(0);
              }}
              className={`w-full text-left p-2.5 rounded-xl transition-all text-xs font-semibold flex items-center gap-3 ${
                currentSlide === idx
                  ? "bg-violet-950/40 text-violet-300 border border-violet-800/50"
                  : "bg-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              <span className="font-mono text-[9px] shrink-0 text-slate-500">
                {(idx + 1).toString().padStart(2, "0")}
              </span>
              <span className="truncate">{slide.title}</span>
            </button>
          ))}
        </div>

        {/* Right Side: Active Presentation Screen */}
        <div className="lg:col-span-9 space-y-4">
          <div 
            id="pitch-deck-stage"
            className="relative rounded-3xl bg-slate-950 border border-white/5 aspect-[16/10] overflow-hidden p-8 sm:p-12 flex flex-col justify-between shadow-2xl shadow-indigo-500/5"
          >
            {/* Top header margin of Slide */}
            <div className="flex justify-between items-start border-b border-white/5 pb-3.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-violet-950/80 border border-violet-800/40 text-[9px] font-mono text-violet-400 font-bold uppercase tracking-wider">
                  {slides[currentSlide].category}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">EduVerse AI Presentation Core</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Slide {currentSlide + 1} of {slides.length}
              </div>
            </div>

            {/* Main Content Area with transition */}
            <div className="flex-grow py-8 overflow-y-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentSlide}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="h-full"
                >
                  {slides[currentSlide].content}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Bottom Footer margin of Slide */}
            <div className="flex justify-between items-center border-t border-white/5 pt-4">
              <span className="text-[9px] text-slate-600 font-mono uppercase tracking-widest">
                Confidential — Investor Presentation 2026
              </span>
              
              {/* Previous / Next Slide controllers */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevSlide}
                  className="p-1.5 rounded-lg bg-slate-900 border border-white/5 hover:border-white/10 text-slate-400 hover:text-white"
                >
                  <ArrowLeft className="h-4 w-4" />
                </button>
                <button
                  onClick={handleNextSlide}
                  className="p-1.5 rounded-lg bg-slate-900 border border-white/5 hover:border-white/10 text-slate-400 hover:text-white"
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* AutoPlay Progress bar */}
            {isPlaying && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-900">
                <div 
                  className="h-full bg-violet-500 transition-all duration-100 ease-linear"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            )}
          </div>

          {/* Presenter Notes Overlay (if toggled) */}
          {showPresenterNotes && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-2xl bg-amber-950/25 border border-amber-500/20 text-xs leading-relaxed text-amber-200 flex gap-3"
            >
              <Info className="h-4.5 w-4.5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block uppercase font-mono text-[9px] text-amber-400 mb-1">Speaker Pitch Script Guidance:</strong>
                {presenterNotes[currentSlide]}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
